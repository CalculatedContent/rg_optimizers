SHAKESPEARE GPT — TWO-PAGE SECTION, VERSION 9

This revision follows the Little Red Schoolhouse structure requested by the
paper's author: classification context, the unresolved value of further
training, a compact reproducible language-model test, evidence, and scope.
The scientific question is how much a fixed small model improves with longer
training and how its collective spectra relate to that improvement.

DELIVERABLES

Shakespeare_GPT_Section_v9.pdf
    Exactly two pages in two columns. A four-line blue results box, one
    comparison table, one individual-seed alpha table, and ONE main figure.
Shakespeare_GPT_Section_v9.tex
    Standalone preview wrapper. Compile twice with pdflatex in this folder.
section_shakespeare_gpt.tex
    The drop-in subsection for insertion after the optimizer experiments.
Shakespeare_GPT_Reproduction_v9.pdf
    Separate five-page reproduction appendix. It is not part of the
    two-page main section.
Shakespeare_GPT_Reproduction_v9.tex
    Standalone reproduction-appendix wrapper.
appendix_shakespeare_reproduction.tex
    Drop-in appendix: complete model, corpus, initialization, random streams,
    objective, optimizers, schedules, calibration, evaluation, spectral fits,
    averaging, uncertainty, commands, continuation, and pinned source links.

INSERTION INTO THE PARENT PAPER

Copy section_shakespeare_gpt.tex and figures/ into the manuscript and use
  \input{section_shakespeare_gpt.tex}
after the optimizer subsection. Insert appendix_shakespeare_reproduction.tex
after the existing optimizer appendix. The parent supplies its marginalbox
style, shared bibliography, and appendix numbering. The subsection refers to
the averaging equation in the preceding subsection, without redefining alpha
or inventing an equation number.

Merge the KarpathyCharRNN and KarpathyNanoGPT entries from
references_shakespeare.bib (or references_shakespeare_bibitems.tex) into the
parent bibliography. MartinPengMahoney2021 is already used by the parent.
No local References or Acknowledgments section is added.

The preview wrappers use 10-point two-column letter paper, 0.68-inch margins,
and 0.23-inch column separation. They substitute readable linked source
citations and Appendix A for the parent macros. The font-map fallback is
inert on a normal TeX Live installation. Parent layout controls final float
placement and numbering.

WHAT IS MEASURED

The short budget is 2,000 updates; the long budget is 20,000 updates, ten
times Karpathy's specific CPU example. Our short measurements are checkpoints
of the same long schedule, not separate short-schedule training runs. The
external example differs in split, evaluation, decay, and weight decay; the
internal same-seed AdamW control is the direct test of the graft correction.

The tuned graft uses reference peak 0.4. At 2,000 updates its validation
loss is 1.851648, PPL is 6.370309, and weighted alpha is 1.808663. Its
same-seed native control has PPL 6.640653. Only confirmation seed 1340 is
complete. Its early advantage reverses at 20,000 updates. The original
reference-0.1 graft is retained in the data and appendix but omitted from
the compact main comparison; it must not be mixed with the tuned result.

All five SGDM runs improve prediction from 2,000 to 20,000 updates. Their
final confidence-weighted, tail-adjusted averages have mean 2.218823 and
sample SD 0.072530, with 95% Student-t interval [2.128765, 2.308881]. This
is evidence for collective near-marginality, not exact equality to 2 or a
recorded SGDM alpha trajectory. Early SGDM/native AdamW spectra are absent.
Native AdamW has lower predictive loss at the matched long budget.

Every spectral average uses ordinary fitted alpha on all 18 unique matrices,
with weights sqrt(num_pl_spikes)/(D+0.02), tied token/output embedding counted
once. This is NOT WeightWatcher's separate alpha_weighted field. The mean
and sample SD across seeds are calculated after each model-level average.
Fit-quality weights, seed uncertainty, and layer heterogeneity are distinct.

FIGURE AND DATA REPRODUCTION

python make_figures.py
    Verifies all 22 input JSON hashes and regenerates the measurement CSVs
    and the archived diagnostic figures from the preceding revision.
python make_section_figure.py
    Rebuilds the SINGLE v9 main figure, figures/sgdm_layer_variation.pdf
    (and PNG), directly from the recorded layer CSVs. It verifies all
    18 matrices x five seeds and each displayed layer mean/sample SD.

The main figure shows all 90 SGDM layer fits at 20,000 updates on one full
range: no zoom panel, no omitted outlier, and no repeated performance or
model-average plot. Dots are individual seeds; bars are each layer's mean
+/- sample SD. The model averages appear as individual seeds in Table 2.
The other archived figures are not used in the v9 main section.

FIGURE_REPRODUCTION.md gives measurement definitions and input provenance.
data/exact_metrics_and_uncertainty.json is the independent numerical audit.
data/raw_manifest.json identifies the 22 exact JSON plotting inputs.
data/raw/ also retains the complete corpus and original reproduction records.

TRAINING FROM SCRATCH

Follow the self-contained appendix or TRAINING_REPRODUCTION.md.
run_sgdm_only.py and Reproduce_Shakespeare_SGDM.ipynb are convenient wrappers;
neither replaces the full written procedure. reproduction/source/ contains
the original native-control training source and manifests.
reproduction/graft_source/ contains the unchanged graft implementation and
portable model/runtime dependencies. The appendix gives exact commands for
native controls, graft runs, and the completed reference-rate selection.
Use the root requirements.txt for recorded numerical package versions.
The upstream portable requirements file is retained as source history.

No training was performed for this manuscript revision. All measurements
come from recorded experiments; no missing spectra were interpolated.
Source pinning improves reproducibility but does not promise bitwise results
across different numerical runtimes and hardware.

SHA256SUMS.txt records the packaged files. The source ZIP excludes LaTeX
auxiliary logs, caches, and temporary page renders.
