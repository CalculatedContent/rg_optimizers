# Reproduce the Shakespeare GPT experiments

The package contains the original training implementation, the exact corpus,
the frozen protocol, and all five SGDM job records. A repository checkout or
notebook is not needed. The launcher invokes only the five SGDM confirmation
jobs and uses `reproduction/source/` directly; it does not download code or data.
The native AdamW comparison and magnitude-graft procedures appear below.
`appendix_shakespeare_reproduction.tex` specifies the complete data, model,
initialization, optimizer equations, schedules, evaluation, and spectral fitting
procedure for an independent implementation without the notebook.

## Source locations

- Experiment repository: [CalculatedContent/rg_optimizers](https://github.com/CalculatedContent/rg_optimizers).
- Original native AdamW/SGDM comparison: [short_test_optimizer_comparison at 39f2fb75](https://github.com/CalculatedContent/rg_optimizers/tree/39f2fb75a3c023d8d90abe11ab06308d1bf3919e/short_test_optimizer_comparison).
- Shared original model and evaluation: [short_test at 39f2fb75](https://github.com/CalculatedContent/rg_optimizers/tree/39f2fb75a3c023d8d90abe11ab06308d1bf3919e/short_test).
- Graft update and rate study: [short_test_adamw_graft at b306247d](https://github.com/CalculatedContent/rg_optimizers/tree/b306247d1b0078a18b1539c68ba14bb64d41a079/short_test_adamw_graft).
- Graft runtime dependencies: [short_test_portable at b306247d](https://github.com/CalculatedContent/rg_optimizers/tree/b306247d1b0078a18b1539c68ba14bb64d41a079/short_test_portable).
- Upstream [TinyShakespeare corpus](https://github.com/karpathy/char-rnn/blob/master/data/tinyshakespeare/input.txt) and [nanoGPT](https://github.com/karpathy/nanoGPT).

The source files and exact corpus are also bundled. The source and raw-data
manifests pin their complete revision IDs and SHA-256 digests.

## 1. Check the package before installing anything

From the extracted package directory:

```bash
python run_sgdm_only.py --check-only
```

This uses only Python's standard library. It verifies the corpus checksum,
all 15 bundled source files, the original worker's 13 Python-source hashes,
the frozen design and SGDM recipe, and all five original result/job records.
It imports no numerical libraries, creates no output directory, and starts no
training. The check covers every frozen job even when `--seeds` selects a subset.

## 2. Prepare the recorded environment

Use Python 3.12 on Linux; Windows users can use WSL. The original worker uses
Unix file locks. A CPU build of PyTorch is sufficient. Install the pinned
packages in a clean environment:

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r reproduction/source/short_test/requirements.txt
```

The requirements record PyTorch 2.14.1, NumPy 2.3.5, SciPy 1.17.0,
WeightWatcher 0.7.7, powerlaw 2.0.0, Matplotlib 3.10.8, and pandas 2.2.3.
Package installation needs access to a package index unless these packages
are already available locally. Training and figure regeneration use the
bundled files. The launcher checks the five numerical package versions in
the original design before starting a worker.

## 3. Run the five seeds

```bash
python run_sgdm_only.py --output runs/sgdm
```

The default output directory is `runs/sgdm` beside the launcher, so the following
also runs all five seeds:

```bash
python run_sgdm_only.py
```

Seeds 1340–1344 run sequentially for 20,000 updates each, using one CPU thread.
The original runs took approximately 30 minutes per seed; local runtime
depends on the CPU and software environment. To start with one seed:

```bash
python run_sgdm_only.py --seeds 1340 --output runs/sgdm
```

Rerun the all-seed command later to retain that completed seed and run the
remaining four. Only seeds from the frozen five-seed protocol are accepted.

The source implementation is preserved byte for byte at commit
`39f2fb75a3c023d8d90abe11ab06308d1bf3919e`. The launcher reads the selected
SGDM recipe from the frozen protocol; it does not rerun calibration or change
hyperparameters. The appendix describes the separate validation-based
calibration procedure. Historical supporting source files are included because
the original worker verifies their hashes, but the launcher does not execute
their training entry points.

## 4. Resume and inspect results

The original worker checkpoints every 250 updates and evaluates loss every
500 updates. Interrupting a running job forwards the signal to the worker
so it can save its state. Exit code 75 means the worker paused. Rerun the same
command and output path to resume the saved model, optimizer, random-number
states, and monitoring history.

For an explicit pause, create a file named `PAUSE` in the output directory.
Remove that file before resuming. Matching completed runs are retained;
conflicting protocol files, jobs, incomplete results, or recorded numerical
failures are reported rather than overwritten. The launcher never loads a
checkpoint itself; the unchanged worker performs its original resume checks.

Each run writes to:

```text
runs/sgdm/confirmation/sgdm_lr0.1_m0.9_seed1340/
```

Replace `1340` with the desired seed. Useful files are:

| File | Contents |
|---|---|
| `job.json` | Frozen recipe, seed, and confirmation phase |
| `last.pt` | Latest model, optimizer, random states, and monitoring history |
| `progress.json` | Current saved step and most recent evaluation |
| `summary_20000.json` | Forty training/validation observations and timing |
| `selection.json` | Endpoint and minimum-validation checkpoint selection |
| `result.json` | Full-partition loss, perplexity, accuracy, and per-matrix fits |

The endpoint used in the paper is always `result.json["endpoint"]` at update
20,000. The minimum-validation checkpoint is retained separately. Compare
new local results with the published measurements in `data/raw/`; keep these
two sets distinct. Hardware and numerical-library builds can affect exact
floating-point results even with identical seeds and source.

## 5. Regenerate the published figures

```bash
python make_figures.py
```

This regenerates the manuscript figures from the bundled **original**
measurements, with their saved hashes and table checks. It does not read
`runs/sgdm`, does not launch training, and does not present locally rerun
models as the published runs. The notebook also displays a separate table
computed from the new or retained local `result.json` files.

## 6. Rebuild the native AdamW/SGDM selection and paired comparison

The frozen AdamW recipe uses peak learning rate 0.001, betas (0.9, 0.99),
epsilon 1e-8, zero weight decay, and the same 100-update warmup and cosine
schedule to 17,000 updates followed by 3,000 at one tenth of the peak. The
original worker uses `fused=False`, the default `foreach` setting, and no AMSGrad.
The selected SGDM recipe is peak 0.1, momentum 0.9, no dampening, no Nesterov,
and no decay. Both clip the global gradient norm to 1 before updating.

The original validation-only calibration at seed 2027 compares six AdamW
candidates (peak 0.0003, 0.001, or 0.003 crossed with decay 0 or 0.1) and six
SGDM candidates (peak 0.01, 0.03, or 0.1 crossed with momentum 0.9 or 0.98).
It screens all to 4,000 updates, continues the best two per optimizer to
20,000, and chooses one recipe per optimizer before confirmation seeds
1340–1344. Ranking uses the lowest full-validation loss at the 500-update
checks, then endpoint loss and candidate ID. It never uses test metrics or
alpha to select hyperparameters.

To repeat this complete procedure, start from the package directory:

```bash
cd reproduction/source/short_test_optimizer_comparison
python comparison.py prepare \
  --data ../../../data/raw/input.txt \
  --output ../../../runs_native_comparison
python comparison.py run \
  --data ../../../data/raw/input.txt \
  --output ../../../runs_native_comparison
```

This is substantially more training than the SGDM-only reproduction. The
driver writes fresh design, calibration, selected-recipe, and confirmation
records. Its full `run` command resumes matching partial runs. The 2,000-update
paper entries are intermediate measurements from the unchanged long schedule;
they are not short-budget models with compressed decay schedules.

## 7. Reproduce the magnitude graft

The graft preserves AdamW's direction and matches each transformer matrix's
update norm to an SGDM reference using the same clipped gradient history.
It acts on the 16 block matrices; embeddings and LayerNorm remain native
AdamW. The original reference peak is 0.1 and the validation-selected peak
is 0.4, with native AdamW peak fixed at 0.001. Keep these recipes separate.

From the package directory, with the recorded environment active:

```bash
cd reproduction/graft_source/short_test_adamw_graft
python run.py preflight --device cpu \
  --data ../../../data/raw/input.txt
python run.py run --device cpu \
  --data ../../../data/raw/input.txt \
  --arm graft --seed 1340 \
  --output ../../../runs_graft01
python reference_lr_study.py --device cpu \
  --data ../../../data/raw/input.txt \
  --output ../../../runs_graft_calibration
```

The first command checks initialization, a short checkpoint replay, and spectral
fitting. The second reproduces the original 0.1 reference. The last screens
reference rates 0.05, 0.1, 0.2, 0.4, and 0.8 at calibration seed 2027, promotes
the two best alternatives plus 0.1 to 20,000 updates, and confirms the selected
alternative on seed 1340. Its ranking uses endpoint validation loss at each
budget, with ties favoring the lower rate. The original study selected 0.4.
Only one confirmation seed is present for each graft recipe in the reported
data. The runner's support for five seeds does not mean five were completed.

These commands start fresh local training. They do not regenerate the published
data by overwriting the archived JSONs. Use the root `requirements.txt` for the
recorded numerical versions; the upstream portable requirements file is retained
for provenance and does not describe the exact recorded package versions.

## 8. Weighted alpha and uncertainty

Use every unique two-dimensional matrix (18 total), keeping packed QKV intact
and counting the tied token/output matrix once. Analyze each through an isolated
bias-free dense wrapper with WeightWatcher 0.7.7 `analyze()` defaults and powerlaw
2.0.0, retaining ordinary `alpha`, `D`, and `num_pl_spikes` from the fit:

```python
w = np.sqrt(num_pl_spikes) / (D + 0.02)
alpha_cw = np.sum(w * alpha) / np.sum(w)
```

Do not substitute WeightWatcher's separate `alpha_weighted`, add a size factor,
or discard successful fits based on their exponent. Preserve and restore the
training random states around spectral analysis. Original SGDM and native AdamW
spectra were saved only at final and minimum-validation checkpoints; their
2,000-update alpha is unavailable. Graft spectra include initialization and
every 500 updates.

Compute one model average per seed, then average the five model averages equally.
Reported SD uses denominator four. For a 95% interval on the five-seed mean,
use `mean ± 2.776445 * sd / sqrt(5)`. Compute each seed's perplexity before taking
its mean and SD. Layers and repeated checkpoints are not independent seed
replicates, and fit-quality weights do not themselves provide confidence bars.

## Optional notebook

Open `Reproduce_Shakespeare_SGDM.ipynb` in a Python 3.12 notebook environment.
It performs the same integrity check, provides an optional dependency-install
cell, launches the five SGDM jobs, displays their local endpoint measurements,
and then explicitly regenerates the published figures from the archived data.
All notebook outputs are empty in the delivered file: no new training was
performed while preparing this package.

The corpus, original sources, protocol files and measurement records are
inputs. Keep edits and experimental variants in a separate copy and output
directory so the frozen reproduction remains inspectable.
