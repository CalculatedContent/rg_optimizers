# Recorded Shakespeare optimizer results: plotting source

Rebuild the two publication figures with:

```bash
python make_figures.py
```

The script requires NumPy, pandas, and Matplotlib. It verifies the SHA-256 hashes
of the 22 bundled raw JSON records before deriving the CSV tables and figures.
It does not train a model, run a model, install dependencies, or access a network.
All paths are relative to this folder. The `--source-root` option is needed only
to assemble a new raw bundle when `data/raw_manifest.json` is absent.

## Figures

- `figures/validation_and_weighted_alpha.pdf`: 7.14 × 2.65 inches. Validation
  perplexity and measured graft alpha histories; SGDM alpha appears only at the
  fixed 20,000-update endpoint.
- `figures/sgdm_layer_endpoints.pdf`: 7.14 × 3.25 inches. All 90 SGDM endpoint
  matrix fits, grouped by the 18 unique matrices, plus a magnified second panel.
- PNG copies are available for quick inspection. PDFs contain embedded fonts.

### Suggested first caption

**Validation and spectral dynamics.** Native AdamW and SGDM show five-seed
mean ± sample SD validation perplexity; each graft curve uses seed 1340.
Graft exponents are measured every 500 updates. SGDM endpoint dots show all five
seeds with a 95% Student t confidence interval for their mean. Curves begin at
500 updates; SGDM dot locations are jittered horizontally only for visibility.

Both graft arms have a recorded initialization exponent of 6.234043715457857.
Those initialization measurements are included in the CSV but omitted from the
plot to keep the later trajectory readable. Rates 0.1 and 0.4 are peak reference
SGDM rates controlling grafted update norms; the native AdamW peak rate is 0.001.

### Suggested second caption

**SGDM endpoint spectra at 20,000 updates.** Dots show all 90 fits (18 matrices,
five seeds); solid markers and error bars show means ± sample SD. The right
panel magnifies the range 0.8–4.8. Green highlights final-block QKV and MLP input
matrices. The dotted line marks alpha = 2.

## Derived data and definitions

- `data/validation_and_alpha_history_per_seed.csv`: 482 measured history rows.
  Missing original SGDM/AdamW early alpha measurements remain empty.
- `data/validation_and_alpha_history_statistics.csv`: per-arm/per-step model
  means and sample SD. Single-seed graft SD remains empty.
- `data/comparison_2000_20000.csv`: the eight original/control/graft timepoint
  rows, including explicit alpha availability and endpoint 95% t intervals.
- `data/endpoint_metrics_per_seed.csv`: fixed endpoint validation/test/training
  metrics and weighted alpha for all 12 models.
- `data/all_recorded_layer_fits.csv`: original 20k endpoint matrix fits plus
  all recorded graft matrix fits, including initialization.
- `data/sgdm_layer_endpoint_summary.csv`: 18 SGDM endpoint matrix summaries.
- `data/metric_definitions.json`: metric, uncertainty, and omission conventions.
- `data/raw_manifest.json`: original source locations, commit IDs, and SHA-256
  for every bundled raw record.

Validation perplexity is `exp(CE)`, with CE in natural-log units per character.
Across seeds, the reported perplexity is the mean of per-seed perplexities.
The validation protocol scores every one of 55,769 targets once, resetting
context every 64 positions and retaining the partial final block.

For all 18 unique weight matrices, the confidence/tail-support weight is
`w = sqrt(num_pl_spikes) / (D_KS + 0.02)`. The plotted aggregate is
`sum(w * alpha) / sum(w)`, using ordinary fitted `alpha`, not WeightWatcher's
`alpha_weighted` field. This is a diagnostic fit-quality/tail-support weighting,
not a calibrated inverse-variance weight. Packed QKV and tied token/output
embeddings each count once. All included fits have status `success`.

Original SGDM and AdamW use five confirmation seeds, 1340–1344. Each graft arm
has one confirmation seed, 1340. PPL ribbons and layer bars show sample SD;
the SGDM aggregate alpha error bar instead shows the two-sided 95% Student t
interval for the mean (`df=4`, critical value `2.7764451051977934`). There are no
graft confidence intervals or invented early SGDM spectra.

All endpoint comparisons use exactly 20,000 updates, not the best-validation
checkpoint. The Karpathy approximately 1.88-loss reference at 2,000 updates is
contextual and uses a different held-out split/evaluation setup; no trajectory,
seed uncertainty, accuracy, or spectral exponent is invented for it here.

## Provenance

- Original five-seed records: `CalculatedContent/rg_optimizers`, frozen source
  commit `39f2fb75a3c023d8d90abe11ab06308d1bf3919e`.
- Graft records: current repository snapshot
  `b306247d1b0078a18b1539c68ba14bb64d41a079`.
- Exact raw origins and hashes are preserved in the manifest. This folder is
  portable and can be rebuilt independently of either repository's availability.
