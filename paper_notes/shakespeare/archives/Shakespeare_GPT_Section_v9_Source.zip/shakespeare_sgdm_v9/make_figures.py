"""Rebuild publication figures from the original recorded evaluations only.

Usage: python make_figures.py [--source-root /path/to/original/workspace]
Dependencies: numpy, pandas, matplotlib. No training, model evaluation, or network.
The first invocation copies the required local JSON records into data/raw; later
invocations verify their recorded SHA-256 hashes and rebuild from those copies.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
import zipfile

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
DATA, FIGS = ROOT / "data", ROOT / "figures"
ORIGINAL_COMMIT = "39f2fb75a3c023d8d90abe11ab06308d1bf3919e"
GRAFT_COMMIT = "b306247d1b0078a18b1539c68ba14bb64d41a079"
BLUE, ORANGE, GREEN = "#2467a0", "#cb571d", "#127f42"
PURPLE, MUTED = "#76558f", "#839397"
INK, GRID, SPINE, REF = "#173e56", "#dde4e8", "#8e9ba6", "#384551"
SEEDS = list(range(1340, 1345))
T95_DF4 = 2.7764451051977934
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": SPINE, "axes.axisbelow": True,
    "axes.labelsize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "savefig.facecolor": "white",
})


def prepare_raw(source_root):
    """Copy exact source bytes once, recording paths, commits, and checksums."""
    raw = DATA / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    manifest_path = DATA / "raw_manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        for item in manifest["files"]:
            assert hashlib.sha256((DATA / item["file"]).read_bytes()).hexdigest() == item["sha256"], item["file"]
        return manifest
    records = []

    def write(name, content, source, commit):
        path = raw / name
        path.write_bytes(content)
        records.append({"file": "raw/" + name, "source": source,
                        "source_commit": commit, "sha256": hashlib.sha256(content).hexdigest()})

    part6 = source_root / "source_data/library_original/GPT_AdamW_SGDM_20261023T031957_Part006.zip"
    for seed in SEEDS:
        for kind in ["result", "summary_20000"]:
            path = source_root / f"source_data/raw/confirmation/sgdm_lr0.1_m0.9_seed{seed}/{kind}.json"
            write(f"sgdm_{seed}_{kind}.json", path.read_bytes(), str(path.relative_to(source_root)), ORIGINAL_COMMIT)
            if seed <= 1342:
                path = source_root / f"source_data/graft_review_current/original_controls/confirmation/adamw_lr0.001_wd0_seed{seed}/{kind}.json"
                write(f"adamw_{seed}_{kind}.json", path.read_bytes(), str(path.relative_to(source_root)), ORIGINAL_COMMIT)
            else:
                member = f"confirmation/adamw_lr0.001_wd0_seed{seed}/{kind}.json"
                with zipfile.ZipFile(part6) as archive:
                    write(f"adamw_{seed}_{kind}.json", archive.read(member),
                          str(part6.relative_to(source_root)) + "::" + member, ORIGINAL_COMMIT)
    graft_root = source_root / "source_data/graft_review_current/short_test_adamw_graft/results"
    for rate, relative in [
        ("0.1", "2026-11-23_seed1340/raw/graft/seed_1340/result.json"),
        ("0.4", "2026-11-23_reference_lr_seed1340/raw/confirmation/rate_0.4/graft/seed_1340/result.json"),
    ]:
        path = graft_root / relative
        write(f"graft_{rate}_1340_result.json", path.read_bytes(), str(path.relative_to(source_root)), GRAFT_COMMIT)
    manifest = {"repository": "CalculatedContent/rg_optimizers", "files": records}
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def load(name):
    return json.loads((DATA / "raw" / name).read_text())


def fit_rows(alpha, arm, seed, step):
    assert alpha["unique_matrices"] == 18
    rows = []
    for matrix in alpha["matrices"]:
        assert len(matrix["fits"]) == 1
        fit = matrix["fits"][0]
        assert fit["status"] == "success"
        a, d, tail = fit["alpha"], fit["D"], fit["num_pl_spikes"]
        assert math.isfinite(a) and d >= 0 and tail > 0
        rows.append({"arm": arm, "seed": seed, "step": step,
                     "matrix": matrix["matrix"], "rows": matrix["shape"][0],
                     "columns": matrix["shape"][1], "alpha": a,
                     "ks_D": d, "tail_count": tail,
                     "weight": math.sqrt(tail) / (d + 0.02),
                     "fit_status": fit["status"]})
    assert len(rows) == 18 and len({r["matrix"] for r in rows}) == 18
    total = sum(r["weight"] for r in rows)
    for row in rows:
        row["normalized_weight"] = row["weight"] / total
    average = sum(r["normalized_weight"] * r["alpha"] for r in rows)
    return average, rows


def history_row(arm, seed, history, weighted_alpha=None):
    m = history["validation"]
    assert m["evaluated_targets"] == 55769
    ce, ppl = m["loss_nats_per_character"], m["perplexity"]
    assert math.isclose(ppl, math.exp(ce), rel_tol=1e-12)
    return {"arm": arm, "seed": seed, "step": history["step"],
            "validation_ce": ce, "validation_ppl": ppl,
            "validation_accuracy_percent": 100 * m["next_character_accuracy"],
            "validation_targets": m["evaluated_targets"],
            "sampled_train_ce": history["train_sample_loss"],
            "weighted_alpha": weighted_alpha}


def endpoint_row(arm, seed, endpoint, weighted_alpha):
    row = {"arm": arm, "seed": seed, "step": endpoint["step"],
           "weighted_alpha": weighted_alpha}
    for split, m in endpoint["metrics"].items():
        row[split + "_ce"] = m["loss_nats_per_character"]
        row[split + "_ppl"] = m["perplexity"]
        row[split + "_accuracy_percent"] = 100 * m["next_character_accuracy"]
    return row


def derive():
    history, endpoints, layers = [], [], []
    for arm in ["SGDM", "AdamW"]:
        for seed in SEEDS:
            prefix = arm.lower()
            result = load(f"{prefix}_{seed}_result.json")
            summary = load(f"{prefix}_{seed}_summary_20000.json")
            assert result["completed"] and result["job"]["seed"] == seed
            assert result["endpoint"]["step"] == summary["step"] == 20000
            assert [h["step"] for h in summary["history"]] == list(range(500, 20001, 500))
            alpha, fit_data = fit_rows(result["endpoint"]["alpha"], arm, seed, 20000)
            layers.extend(fit_data)
            endpoints.append(endpoint_row(arm, seed, result["endpoint"], alpha))
            for h in summary["history"]:
                history.append(history_row(arm, seed, h, alpha if h["step"] == 20000 else None))
            assert math.isclose(summary["history"][-1]["validation"]["loss_nats_per_character"],
                                result["endpoint"]["metrics"]["validation"]["loss_nats_per_character"], rel_tol=1e-12)
    for rate in ["0.1", "0.4"]:
        arm = "Graft " + rate
        result = load(f"graft_{rate}_1340_result.json")
        assert result["completed"] and result["seed"] == 1340
        assert [h["step"] for h in result["history"]] == list(range(0, 20001, 500))
        for h in result["history"]:
            alpha, fit_data = fit_rows(h["alpha"], arm, 1340, h["step"])
            history.append(history_row(arm, 1340, h, alpha))
            layers.extend(fit_data)
        endpoint_alpha, _ = fit_rows(result["endpoint"]["alpha"], arm, 1340, 20000)
        assert math.isclose(alpha, endpoint_alpha, abs_tol=1e-12)
        endpoints.append(endpoint_row(arm, 1340, result["endpoint"], endpoint_alpha))
    history, endpoints, layers = map(pd.DataFrame, [history, endpoints, layers])
    history.to_csv(DATA / "validation_and_alpha_history_per_seed.csv", index=False, float_format="%.15g")
    endpoints.to_csv(DATA / "endpoint_metrics_per_seed.csv", index=False, float_format="%.15g")
    layers.to_csv(DATA / "all_recorded_layer_fits.csv", index=False, float_format="%.15g")

    group = history.groupby(["arm", "step"], sort=False)
    statistics = group.agg(n=("seed", "size"),
        validation_ce_mean=("validation_ce", "mean"), validation_ce_sd=("validation_ce", "std"),
        validation_ppl_mean=("validation_ppl", "mean"), validation_ppl_sd=("validation_ppl", "std"),
        validation_accuracy_percent_mean=("validation_accuracy_percent", "mean"),
        validation_accuracy_percent_sd=("validation_accuracy_percent", "std"),
        weighted_alpha_mean=("weighted_alpha", "mean"), weighted_alpha_sd=("weighted_alpha", "std")).reset_index()
    statistics.to_csv(DATA / "validation_and_alpha_history_statistics.csv", index=False, float_format="%.15g")
    selected = statistics[statistics.step.isin([2000, 20000])].copy()
    selected["alpha_available"] = selected.weighted_alpha_mean.notna()
    selected["weighted_alpha_ci95_low"] = selected.weighted_alpha_mean - T95_DF4 * selected.weighted_alpha_sd / np.sqrt(selected.n)
    selected["weighted_alpha_ci95_high"] = selected.weighted_alpha_mean + T95_DF4 * selected.weighted_alpha_sd / np.sqrt(selected.n)
    selected.to_csv(DATA / "comparison_2000_20000.csv", index=False, float_format="%.15g")
    return history, endpoints, layers, statistics


def grid(ax, axis="y"):
    ax.grid(axis=axis, linewidth=0.5, color=GRID)
    ax.tick_params(length=2.5, pad=2)


def save(fig, name):
    fixed = datetime(2000, 1, 1, tzinfo=timezone.utc)
    fig.savefig(FIGS / f"{name}.pdf", metadata={"CreationDate": fixed, "ModDate": fixed})
    fig.savefig(FIGS / f"{name}.png", dpi=250)
    plt.close(fig)


def validation_panel(ax, statistics):
    for arm, color, label in [("SGDM", BLUE, "SGDM (5 seeds)"), ("AdamW", PURPLE, "AdamW (5 seeds)")]:
        data = statistics[(statistics.arm == arm) & (statistics.step >= 500)]
        x, y, sd = data.step.to_numpy() / 1000, data.validation_ppl_mean.to_numpy(), data.validation_ppl_sd.to_numpy()
        ax.fill_between(x, y - sd, y + sd, color=color, alpha=.17, lw=0)
        ax.plot(x, y, color=color, lw=1.6, label=label)
    for arm, color, style, label in [
        ("Graft 0.1", MUTED, "--", r"Graft ref. 0.1 ($n=1$)"),
        ("Graft 0.4", ORANGE, "-", r"Graft ref. 0.4 ($n=1$)"),
    ]:
        data = statistics[(statistics.arm == arm) & (statistics.step >= 500)]
        ax.plot(data.step / 1000, data.validation_ppl_mean, color=color, ls=style, lw=1.35, label=label)
        row = data[data.step == 2000].iloc[0]
        ax.scatter(2, row.validation_ppl_mean, color=color, s=15, edgecolors="white", linewidths=.35, zorder=5)
    ax.set(xlim=(0, 20.6), ylim=(3.85, 11.55), xticks=[0, 2, 5, 10, 15, 20],
           yticks=[4, 6, 8, 10], xlabel="Optimizer updates (thousands)", ylabel="Validation perplexity")
    ax.axvline(2, color=GRID, lw=.7, ls=":", zorder=0)
    grid(ax)
    ax.set_title("(a) Validation performance", loc="left", fontsize=9.2, color=INK, weight="bold")
    ax.legend(loc="upper right", frameon=False, fontsize=8, handlelength=1.7, labelspacing=.25)
    ax.text(.98, .54, "Bands: ±1 sample SD", transform=ax.transAxes, ha="right", va="top", fontsize=8, color=REF)


def alpha_panel(ax, history, endpoints):
    ax.axhline(2, color=REF, lw=.9, ls=":", zorder=0)
    for arm, color, style, label in [
        ("Graft 0.1", MUTED, "--", r"Graft ref. 0.1 ($n=1$)"),
        ("Graft 0.4", ORANGE, "-", r"Graft ref. 0.4 ($n=1$)"),
    ]:
        data = history[(history.arm == arm) & (history.step >= 500)]
        ax.plot(data.step / 1000, data.weighted_alpha, color=color, ls=style, lw=1.45, label=label)
        row = data[data.step == 2000].iloc[0]
        ax.scatter(2, row.weighted_alpha, color=color, s=18, edgecolors="white", linewidths=.4, zorder=5)
    values = endpoints[endpoints.arm.eq("SGDM")].sort_values("seed").weighted_alpha.to_numpy()
    mean, sd = values.mean(), values.std(ddof=1)
    halfwidth = T95_DF4 * sd / math.sqrt(5)
    # Horizontal jitter is graphical only: every one of these fits is at step 20,000.
    ax.scatter(20 + np.linspace(-.32, .32, 5), values, s=17, color=BLUE,
               edgecolors="white", linewidths=.4, alpha=.65, zorder=4)
    ax.errorbar(20, mean, yerr=halfwidth, fmt="D", ms=4, color=BLUE,
                markeredgecolor="white", markeredgewidth=.45, capsize=3, elinewidth=1.2,
                label="SGDM 20k: 5 seeds, 95% CI", zorder=5)
    ax.annotate("1.809", xy=(2, 1.8086630636031662), xytext=(3.2, 1.67),
                fontsize=8, color=ORANGE, ha="left", va="bottom",
                arrowprops={"arrowstyle": "-", "lw": .6, "color": ORANGE})
    ax.text(13.9, 1.78, "SGDM: endpoint spectra only", fontsize=8, color=REF, ha="center")
    ax.set(xlim=(0, 20.7), ylim=(1.6, 3.52), xticks=[0, 2, 5, 10, 15, 20],
           yticks=[2, 2.5, 3, 3.5], xlabel="Optimizer updates (thousands)",
           ylabel=r"Weighted mean $\bar{\alpha}_{\mathrm{cw}}$")
    grid(ax)
    ax.set_title("(b) Measured spectral exponents", loc="left", fontsize=9.2, color=INK, weight="bold")
    ax.legend(loc="upper left", frameon=False, fontsize=8, handlelength=1.7, labelspacing=.25)


def trajectory_figures(history, endpoints, statistics):
    fig, axes = plt.subplots(1, 2, figsize=(7.14, 2.65), layout="constrained")
    validation_panel(axes[0], statistics)
    alpha_panel(axes[1], history, endpoints)
    save(fig, "validation_and_weighted_alpha")


def layer_figure(layers):
    data = layers[(layers.arm == "SGDM") & (layers.step == 20000)].copy()
    assert len(data) == 90
    order = ["transformer.wte.weight", "transformer.wpe.weight"]
    labels = ["Token / head", "Position"]
    for i in range(4):
        for name, label in [("attn.c_attn", "QKV"), ("attn.c_proj", "Attn out"),
                            ("mlp.c_fc", "MLP in"), ("mlp.c_proj", "MLP out")]:
            order.append(f"transformer.h.{i}.{name}.weight")
            labels.append(f"B{i+1} {label}")
    assert set(order) == set(data.matrix)
    summary = data.groupby("matrix").alpha.agg(["count", "mean", "std", "min", "max"]).reindex(order)
    summary.insert(0, "label", labels)
    summary.rename(columns={"count": "n", "mean": "alpha_mean", "std": "alpha_sample_sd", "min": "alpha_min", "max": "alpha_max"}).to_csv(DATA / "sgdm_layer_endpoint_summary.csv", float_format="%.15g")
    fig, axes = plt.subplots(1, 2, figsize=(7.14, 3.25), sharey=True,
        gridspec_kw={"width_ratios": [1.15, 1]}, layout="constrained")
    offsets = np.linspace(-.18, .18, 5)
    for ax in axes:
        for row in [1.5, 5.5, 9.5, 13.5]:
            ax.axhline(row, color=GRID, lw=.7)
        ax.axvline(2, color=REF, lw=1.1, ls=":")
        for i, matrix in enumerate(order):
            values = data[data.matrix.eq(matrix)].sort_values("seed").alpha.to_numpy()
            ax.scatter(values, np.full(5, i) + offsets, s=9, color=BLUE, alpha=.32, edgecolors="none", zorder=2)
            color = GREEN if matrix in ["transformer.h.3.attn.c_attn.weight", "transformer.h.3.mlp.c_fc.weight"] else BLUE
            row = summary.loc[matrix]
            ax.errorbar(row["mean"], i, xerr=row["std"], fmt="o", color=color,
                elinewidth=1.05, capsize=1.6, markersize=3.2,
                markeredgecolor="white", markeredgewidth=.35, zorder=3)
        ax.set(yticks=np.arange(18), ylim=(17.55, -.55), xlabel=r"Fitted exponent $\alpha$")
        grid(ax, axis="x")
        ax.tick_params(axis="y", length=0)
    axes[0].set_yticklabels(labels, fontsize=8)
    axes[0].set(xlim=(.8, 14.7), xticks=[1, 2, 4, 6, 8, 10, 12, 14])
    axes[1].set(xlim=(.8, 4.8), xticks=[1, 2, 3, 4])
    axes[0].set_title("(a) SGDM at 20k: all 18 matrices", loc="left", fontsize=9.2, color=INK, weight="bold")
    axes[1].set_title("(b) Detail near the marginal regime", loc="left", fontsize=9.2, color=INK, weight="bold")
    legend = [
        Line2D([], [], marker="o", ms=4, lw=1, color=BLUE, label="Mean ± sample SD (5 seeds)"),
        Line2D([], [], marker="o", ms=3, lw=0, color=BLUE, alpha=.32, label="Individual seed"),
        Line2D([], [], color=REF, lw=1.1, ls=":", label=r"$\alpha=2$"),
    ]
    axes[0].legend(handles=legend, loc="lower right", frameon=False, fontsize=8, handlelength=1.4, labelspacing=.2)
    save(fig, "sgdm_layer_endpoints")


def write_notes(history, endpoints, manifest):
    notes = {
        "original_source_commit": ORIGINAL_COMMIT,
        "current_graft_source_commit": GRAFT_COMMIT,
        "raw_file_count": len(manifest["files"]),
        "validation": "Cross entropy in natural-log units per character; perplexity=exp(CE). Full contiguous 5% validation split, 55,769 next-character targets, context reset every 64 positions, partial final block retained.",
        "perplexity_aggregation": "Arithmetic mean of the five per-seed perplexities; ribbons are ±1 sample SD (ddof=1), not confidence intervals.",
        "weighted_alpha": "For all 18 unique matrices, w_l=sqrt(num_pl_spikes_l)/(D_KS_l+0.02); alpha_bar=sum(w_l*alpha_l)/sum(w_l). Ordinary alpha is used, not WeightWatcher's alpha_weighted. All fits are successful; packed QKV and the tied token/output matrix each count once.",
        "weighting_interpretation": "Fit-quality and fitted-tail-support weighting; not calibrated inverse-variance uncertainty.",
        "sgdm_aggregate_uncertainty": "Equal weight per seed; 95% Student t interval for the mean, df=4, t*=2.7764451051977934. Five endpoint dots have ±320-update horizontal jitter only for visibility; all true steps are 20,000.",
        "layer_uncertainty": "Layer means and ±1 sample SD across the same five seeds, with all 90 individual fits shown. This is not a 95% interval.",
        "graft_uncertainty": "Each reference rate has one confirmation seed (1340). No SD ribbon or confidence interval is calculated for either graft arm.",
        "trajectory_times": "Validation plotted at 500,1000,...,20000. Graft alpha is measured at 0,500,...,20000; plotted from 500 for legibility. Both initial alpha values are 6.234043715457857 and are retained in CSV. Lines connect recorded graft measurements only.",
        "missing_spectra": "Original SGDM and AdamW have no recorded alpha at 2,000 updates. Their early-alpha CSV entries remain missing. There is no interpolated SGDM alpha curve.",
        "karpathy_context": "No Karpathy trajectory or uncertainty is invented. The external reported approximately 1.88 loss at 2,000 updates is a contextual benchmark with a different held-out split/evaluation protocol, to be discussed separately in the report.",
        "endpoint_choice": "All comparisons use fixed 20,000-update endpoints, not best-validation checkpoints.",
        "graft_rates": "0.1 and 0.4 are reference SGDM peak rates controlling grafted block update norms, not native AdamW peak rates. Native AdamW peak LR is 0.001 for both.",
        "counts": {"original_models": 10, "original_history_records": 400, "graft_models": 2, "graft_history_records": 82, "sgdm_endpoint_matrix_fits": 90},
    }
    (DATA / "metric_definitions.json").write_text(json.dumps(notes, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, default=ROOT.parent.parent)
    args = parser.parse_args()
    DATA.mkdir(exist_ok=True)
    FIGS.mkdir(exist_ok=True)
    manifest = prepare_raw(args.source_root.resolve())
    history, endpoints, layers, statistics = derive()
    trajectory_figures(history, endpoints, statistics)
    layer_figure(layers)
    write_notes(history, endpoints, manifest)
    report = statistics[statistics.step.isin([2000, 20000])][["arm", "step", "n", "validation_ppl_mean", "validation_ppl_sd", "weighted_alpha_mean", "weighted_alpha_sd"]]
    print(report.to_string(index=False, float_format=lambda v: f"{v:.9f}"))
    print(f"Saved {len(manifest['files'])} verified raw records; {len(history)} history records and {len(layers)} matrix fits.")


if __name__ == "__main__":
    main()
