# Shakespeare GPT trained with SGD and momentum

This revised two-page subsection is for insertion immediately after the optimizer
experiments in *A Spectral Renormalization-Group View of Learning*. It introduces
a small CPU GPT example, then presents training convergence and model-level
marginality across five independent seeds. The manuscript repeats no alpha or
weighted-average definitions; it refers to the preceding averaging equation.

## Manuscript files

- `Shakespeare_SGDM_Subsection_v4.pdf`: rendered two-column excerpt.
- `section_shakespeare_sgdm.tex`: drop-in subsection, without a document preamble.
- `Shakespeare_SGDM_Subsection_v4.tex`: standalone compilation wrapper, matching
  the paper's 10 pt, two-column, letter-paper layout, 0.68-inch margins,
  0.23-inch column separation, and existing blue `marginalbox` styling.
- `figures/`: both figures as vector PDF and 250 dpi PNG.
- `references_shakespeare.bib`: corpus and nanoGPT references to merge into
  the main paper's bibliography.
- `TRAINING_REPRODUCTION.md` and `run_sgdm_only.py`: instructions and a launcher
  for rerunning the five frozen SGDM jobs on a CPU.

Copy the subsection and `figures/` files into the manuscript directory. After
the existing optimizer subsection, add:

```latex
\input{section_shakespeare_sgdm.tex}
```

The insert uses the existing theoretical label `sxn:model_average_marginality`
and bibliography key `MartinPengMahoney2021`. Merge the two entries in
`references_shakespeare.bib` into the main bibliography (or add that file to
the parent's bibliography inputs). The new keys are `KarpathyCharRNN` and
`KarpathyNanoGPT`. The original corpus citation points to the char-rnn release;
the nanoGPT citation supplies the model implementation and reference losses.

The averaging-equation reference is textual (the preceding optimizer
subsection), so it introduces no duplicate equation or assumed equation
number. Citation macros use ordinary `\cite` commands in the parent paper.
The standalone wrapper overrides them with linked author/source citations
and a descriptive marginality cross-reference. It renders no separate
References or Acknowledgments section.

Version 4 replaces generic box statements with the model, training budget,
optimizer settings, measured alpha/loss/perplexity, runtime, and final-block
exponents. It adds the calibration grid, exact sampling and evaluation
protocol, effective corpus passes, matrix dimensions, and contextual nanoGPT
loss comparisons. All experimental results still use the original five runs.

The parent manuscript needs `amsmath`, `graphicx`, `booktabs`, `caption`,
`hyperref`, `ragged2e`, `tcolorbox`, and its existing `marginalbox` style.
Figure, equation, table, and subsection numbering inherit the parent document.
The standalone preview suppresses subsection numbering only; it does not
change the insert. Float positions can shift in the full manuscript.

Compile the standalone excerpt with a normal TeX Live installation:

```bash
pdflatex -interaction=nonstopmode -halt-on-error Shakespeare_SGDM_Subsection_v4.tex
pdflatex -interaction=nonstopmode -halt-on-error Shakespeare_SGDM_Subsection_v4.tex
```

The current complete manuscript was not overwritten. This is a separately
reviewable subsection, using the verified paper style and latest optimizer
plot palette.

## Regenerating the figures

To train the models again, follow `TRAINING_REPRODUCTION.md`. The commands
below regenerate the paper figures directly from the bundled measurements.

```bash
python -m pip install numpy pandas matplotlib
python make_figures.py
```

The revised learning figure shows all five individual training and validation
trajectories as thin lines and their means as thick lines. The weighted-alpha
panel remains an endpoint comparison.

The script checks the original measurement-file hashes, recomputes the weighted
averages and loss histories, checks the derived endpoint table, recomputes the
unigram baseline, and writes both figures. It requires no training, network
access, or model checkpoints.

`data/raw/` contains the original SGDM result and loss-history JSON records for
seeds 1340–1344, together with the exact TinyShakespeare text. The script uses
only the common 20,000-update endpoint. `data/raw_sha256.json` retains the hashes
of the supplied raw records. The original archive checks were also verified
against their archived integrity manifest during recovery.

`data/sgdm_layer_fits.csv` retains both final and minimum-validation spectral
measurements for provenance. Use `checkpoint == "endpoint"` for the final
experiment. All manuscript figures and final statistics use that selection.
The minimum-validation checkpoint differs from the endpoint only for seed
1344, where it occurs at update 19,000.

## Main results

All uncertainty below is sample SD across five independent seeds.

| Quantity | Mean ± sample SD |
|---|---:|
| Weighted average α | 2.218823 ± 0.072530 |
| Unweighted average α | 2.950698 ± 0.211426 |
| Full training CE | 1.363934 ± 0.010215 nats/character |
| Full validation CE | 1.528045 ± 0.008810 nats/character |
| Full test CE | 1.694025 ± 0.008160 nats/character |
| Test perplexity | 5.441484 ± 0.044370 |
| Test accuracy | 51.284764% ± 0.122313 percentage points |
| Update time | 27.286341 ± 1.910091 minutes per seed |
| Training, monitoring and final evaluation | 29.744827 ± 2.002260 minutes per seed |

The loss is meaningful on this task: a train-only unigram predictor scores
3.361967 nats/character and perplexity 28.845885 on exactly the same test targets.
The uniform 65-character predictor has cross-entropy log(65) = 4.174387.
The training-frequency estimate uses the training next-character targets only,
and every character occurs in training, so no smoothing is required.

For each seed separately, the model statistic is

```text
w_l = sqrt(n_tail_l) / (D_KS_l + 0.02)
alpha_cw = sum(w_l * alpha_l) / sum(w_l)
```

`n_tail_l` is WeightWatcher's `num_pl_spikes` and `D_KS_l` is its `D` field.
The statistic uses the ordinary fitted `alpha`, not WeightWatcher's distinct
`alpha_weighted` quantity. It does not add a separate matrix-size multiplier.
These are fit-quality and tail-support weights, not calibrated inverse-variance
confidence weights. The five seed-level averages are then averaged equally.

## What the measurements establish

The reproducible finding is a weighted model average near the predicted
marginal exponent, with useful held-out prediction. The final block's packed
QKV and MLP-input matrices have α = 1.987626 ± 0.181561 and
1.945099 ± 0.061524. All 18 unique matrices are shown in the layer figure,
including earlier-block outliers and several later MLP-output matrices near
1.4–1.5. Exactly 22/90 fits lie within 2 ± 0.5. The data do not establish
that most individual matrices have exponent two.

There is no recorded α time series: spectra were evaluated at final and
minimum-validation checkpoints. The loss history contains 40 real measurements
per seed, at updates 500 through 20,000. The training history is a fixed sampled
estimate; the validation history is full-partition evaluation. No interpolation
or invented initial points are used. Figure 1(b) is explicitly a comparison
across independent endpoint models.

## Frozen training recipe and sources

Four blocks, four attention heads per block, width 128, context 64, vocabulary
65, 804,096 unique parameters, tied output/token embedding, no biases or
dropout. Fixed contiguous 90/5/5 train/validation/test split. Five seeds,
20,000 updates, batch 12, float32 CPU, one thread. Standard SGDM with momentum
0.9, peak learning rate 0.1, gradient clipping at norm 1, zero decay and
dampening, no Nesterov. A 100-update warmup is followed by cosine decay to
0.01 at update 17,000 and 3,000 updates at that floor. Each run processes
15,360,000 target positions. Evaluation resets context at blocks of up to
64 characters and scores all 55,769 test targets exactly once.

The recipe was selected on validation data in a separate calibration and frozen
before fresh-seed confirmation. Alpha did not select the recipe. The fixed
corpus/split had been used in an earlier exploratory pilot; no test-guided
retuning was performed for confirmation.

- Frozen source commit: `39f2fb75a3c023d8d90abe11ab06308d1bf3919e`.
- [Training/confirmation runner](https://github.com/CalculatedContent/rg_optimizers/tree/39f2fb75a3c023d8d90abe11ab06308d1bf3919e/short_test_optimizer_comparison).
- [Architecture, data and evaluation helpers](https://github.com/CalculatedContent/rg_optimizers/tree/39f2fb75a3c023d8d90abe11ab06308d1bf3919e/short_test).
- [nanoGPT CPU model example](https://github.com/karpathy/nanoGPT).
- Original final archives: `GPT_AdamW_SGDM_20261023T031957_Part006.zip`
  (seed 1340) and `Part007.zip` (seeds 1341–1344). Only the SGDM records are
  included in this package.
- Data SHA256: `86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed`.
- WeightWatcher version: 0.7.7; default per-matrix fits with packed QKV,
  token/output matrix deduplicated, and LayerNorm vectors excluded.
- Paper style reference: `rg_theory_paper_arxiv`, commit
  `2d5e752c65188bf8a194163a01b76839b516252d`.
- Plot style reference: `rg_optimizers` PR 182, head
  `3c311af2a36cc11c324c3dd11a2c1931435c3178`.

The subsection and figure regeneration were prepared on November 24, 2026.
No model was retrained while preparing these files.

## External loss references

- Corpus provenance: https://github.com/karpathy/char-rnn
- Reference examples: https://github.com/karpathy/nanoGPT/blob/master/README.md
- Reference split: https://github.com/karpathy/nanoGPT/blob/master/data/shakespeare_char/prepare.py
- Reference configuration: https://github.com/karpathy/nanoGPT/blob/master/config/train_shakespeare_char.py
- Reference sampled evaluation: https://github.com/karpathy/nanoGPT/blob/master/train.py

The README's CPU result is labeled simply as loss. The larger example is
explicitly best validation loss. Reference perplexities in the subsection
are calculated from the reported cross-entropies; they are not new measured
runs. The main text states the different split and evaluation protocol.
