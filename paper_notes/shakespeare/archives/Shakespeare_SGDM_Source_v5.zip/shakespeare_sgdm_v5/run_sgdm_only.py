"""Launch the five saved SGDM confirmation jobs with the frozen original runner.

Use the original study's Linux/Python 3.12 environment and dependencies.
This launcher was checked against the runner interface; no new training was
performed while preparing the manuscript. It preserves and resumes outputs.
"""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

SOURCE_COMMIT = "39f2fb75a3c023d8d90abe11ab06308d1bf3919e"
BUNDLE = Path(__file__).resolve().parent


def completed_result_matches(path, job, design_sha256):
    if not path.is_file():
        return False
    try:
        result = json.loads(path.read_text())
    except (OSError, ValueError):
        return False
    return (
        result.get("completed") is True
        and result.get("job") == job
        and result.get("endpoint", {}).get("step") == 20000
        and result.get("design_sha256") == design_sha256
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="Checkout of the frozen rg_optimizers commit")
    parser.add_argument("--output", type=Path, required=True, help="New or matching SGDM output directory")
    args = parser.parse_args()
    repo, work = args.repo.resolve(), args.output.resolve()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    if head != SOURCE_COMMIT:
        raise SystemExit(f"Expected source commit {SOURCE_COMMIT}; found {head}")
    worker = repo / "short_test_optimizer_comparison/comparison.py"
    if not worker.is_file():
        raise SystemExit("The frozen experiment runner is missing")
    work.mkdir(parents=True, exist_ok=True)
    for name in ("design.json", "recipes.json"):
        source, target = BUNDLE / "data/protocol" / name, work / name
        if target.exists():
            if target.read_bytes() != source.read_bytes():
                raise SystemExit(f"Existing protocol differs; choose a new output directory: {target}")
        else:
            shutil.copyfile(source, target)
    design_sha256 = hashlib.sha256((work / "design.json").read_bytes()).hexdigest()
    for seed in range(1340, 1345):
        original = json.loads((BUNDLE / f"data/raw/seed{seed}_result.json").read_text())
        job = original["job"]
        assert job["seed"] == seed and job["recipe"]["optimizer"] == "SGDM"
        folder = work / "confirmation" / f"{job['recipe']['id']}_seed{seed}"
        folder.mkdir(parents=True, exist_ok=True)
        job_file = folder / "job.json"
        if job_file.exists():
            if json.loads(job_file.read_text()) != job:
                raise SystemExit(f"Existing job differs: {job_file}")
        else:
            job_file.write_text(json.dumps(job, indent=2) + "\n")
        result_file = folder / "result.json"
        if result_file.exists():
            if completed_result_matches(result_file, job, design_sha256):
                print(f"Seed {seed}: matching completed run retained", flush=True)
                continue
            raise SystemExit(f"Existing result is not the expected completed run: {result_file}")
        subprocess.run([
            sys.executable, str(worker), "worker", "--output", str(work),
            "--data", str(BUNDLE / "data/raw/input.txt"), "--job", str(job_file),
            "--target", "20000",
        ], cwd=repo, check=True)
        if not completed_result_matches(result_file, job, design_sha256):
            failure = folder / "numerical_failure.json"
            detail = f" See {failure}" if failure.is_file() else f" Inspect {folder}"
            raise SystemExit(f"Seed {seed}: worker did not produce a matching completed result.{detail}")
    print(f"Five SGDM results: {work / 'confirmation'}")


if __name__ == "__main__":
    main()
