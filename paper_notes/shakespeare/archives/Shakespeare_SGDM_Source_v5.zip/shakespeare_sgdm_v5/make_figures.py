"""Rebuild the SGDM manuscript figures and verify the table against raw records.

Run: python make_figures.py
Dependencies: numpy, pandas, matplotlib. No training or network access is used.
All statistics use the fixed 20,000-update endpoint and sample SD over five seeds.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
DATA, FIGS = ROOT / "data", ROOT / "figures"
FIGS.mkdir(exist_ok=True)
BLUE, ORANGE, GREEN = "#2467a0", "#cb571d", "#127f42"
INK, GRID, SPINE, REF = "#173e56", "#dde4e8", "#8e9ba6", "#384551"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": SPINE, "axes.axisbelow": True,
    "axes.labelsize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "savefig.facecolor": "white",
})


def verify_raw():
    manifest = json.loads((DATA / "raw_sha256.json").read_text())
    for name, expected in manifest.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Raw record checksum mismatch: {name}")
    endpoint, histories, layers = [], [], []
    for seed in range(1340, 1345):
        result = json.loads((DATA / "raw" / f"seed{seed}_result.json").read_text())
        summary = json.loads((DATA / "raw" / f"seed{seed}_summary_20000.json").read_text())
        record = result["endpoint"]
        assert record["step"] == summary["step"] == 20000
        assert len(record["alpha"]["matrices"]) == 18
        alpha, weights = [], []
        for matrix in record["alpha"]["matrices"]:
            fit = matrix["fits"][0]
            assert fit["status"] == "success"
            a, d, n = fit["alpha"], fit["D"], fit["num_pl_spikes"]
            assert math.isfinite(a) and d >= 0 and n > 0
            weight = math.sqrt(n) / (d + 0.02)
            alpha.append(a)
            weights.append(weight)
            layers.append(dict(seed=seed, matrix=matrix["matrix"], alpha=a))
        endpoint.append(dict(
            seed=seed, weighted_alpha=np.average(alpha, weights=weights),
            unweighted_alpha=np.mean(alpha),
            test_loss=record["metrics"]["test"]["loss_nats_per_character"],
            test_perplexity=record["metrics"]["test"]["perplexity"],
        ))
        assert len(summary["history"]) == 40
        for h in summary["history"]:
            histories.append(dict(seed=seed, step=h["step"],
                train_sample_loss=h["train_sample_loss"],
                validation_loss=h["validation"]["loss_nats_per_character"]))
    recomputed = pd.DataFrame(endpoint)
    saved = pd.read_csv(DATA / "sgdm_endpoint_metrics.csv")
    assert np.allclose(recomputed.weighted_alpha, saved.weighted_alpha, atol=1e-12)
    assert np.allclose(recomputed.test_loss, saved.test_loss_nats_per_character, atol=1e-12)
    return recomputed, pd.DataFrame(histories), pd.DataFrame(layers)


def grid(ax, axis="y"):
    ax.grid(axis=axis, linewidth=0.5, color=GRID)
    ax.tick_params(length=2.5, pad=2)


def save(fig, name):
    fixed = datetime(2000, 1, 1, tzinfo=timezone.utc)
    fig.savefig(FIGS / f"{name}.pdf", metadata={"CreationDate": fixed, "ModDate": fixed})
    fig.savefig(FIGS / f"{name}.png", dpi=250)
    plt.close(fig)


def learning_figure(endpoint, history):
    # Sized to the manuscript column (3.455 inches). Values are not smoothed.
    fig, (ax, bx) = plt.subplots(2, 1, figsize=(3.455, 3.45),
        gridspec_kw={"height_ratios": [1.35, 1]}, layout="constrained")
    for field, color, label in [
        ("train_sample_loss", BLUE, "Training (sampled)"),
        ("validation_loss", ORANGE, "Validation (full)"),
    ]:
        # Every thin line is one observed seed trajectory. The mean is drawn
        # last and no SD ribbon hides the individual measurements.
        for _, seed_history in history.sort_values("step").groupby("seed"):
            ax.plot(seed_history.step.to_numpy() / 1000,
                seed_history[field].to_numpy(), color=color,
                lw=0.65, alpha=0.38, zorder=2)
        grouped = history.groupby("step")[field].agg(["mean", "std"])
        x = grouped.index.to_numpy() / 1000
        mean = grouped["mean"].to_numpy()
        ax.plot(x, mean, color=color, lw=1.65, label=label, zorder=3)
    ax.set(xlim=(0, 20), ylim=(1.25, 2.55), xticks=[0, 5, 10, 15, 20],
        xlabel="Training updates (thousands)", ylabel="Cross-entropy (nats/char)")
    ax.set_title("(a) Learning across five seeds", loc="left", fontsize=9.5, color=INK, weight="bold")
    grid(ax)
    ax.legend(frameon=False, fontsize=7.4, loc="upper right", handlelength=1.6)
    ax.text(0.98, 0.54, "Thin: each seed\nThick: mean", transform=ax.transAxes,
        fontsize=7.0, color=REF, ha="right", va="top", linespacing=1.25)
    bx.axhline(2, color=REF, lw=1.1, ls=":", label=r"RG reference $\alpha=2$")
    mean, sd = endpoint.weighted_alpha.mean(), endpoint.weighted_alpha.std(ddof=1)
    bx.axhspan(mean - sd, mean + sd, color=BLUE, alpha=0.10, lw=0)
    bx.axhline(mean, color=BLUE, lw=1.0, alpha=0.65)
    x = np.arange(5)
    bx.scatter(x, endpoint.weighted_alpha, s=25, color=BLUE, edgecolor="white", linewidth=0.5, zorder=3)
    for xx, yy in zip(x, endpoint.weighted_alpha):
        bx.text(xx, yy + 0.022, f"{yy:.3f}", fontsize=7.1, ha="center", color=INK)
    bx.set(xticks=x, xticklabels=endpoint.seed, xlabel="Independent seed", ylabel=r"Weighted average $\bar{\alpha}_{\rm cw}$",
           xlim=(-0.5, 4.5), ylim=(1.95, 2.40), yticks=[2.0, 2.1, 2.2, 2.3, 2.4])
    bx.set_title("(b) Weighted α at 20,000 updates", loc="left", fontsize=9.3, color=INK, weight="bold")
    grid(bx)
    save(fig, "shakespeare_learning_and_average")


def layer_figure(layers):
    summary = pd.read_csv(DATA / "sgdm_layer_summary.csv")
    order = summary.matrix.to_list()
    positions = np.arange(len(order))
    labels = summary.label.str.replace("Attention", "Attn", regex=False).to_list()
    fig, axes = plt.subplots(1, 2, figsize=(7.14, 3.78), sharey=True,
        gridspec_kw={"width_ratios": [1.15, 1]}, layout="constrained")
    offsets = np.linspace(-0.18, 0.18, 5)
    for ax in axes:
        for row in [1.5, 5.5, 9.5, 13.5]:
            ax.axhline(row, color=GRID, lw=0.7)
        ax.axvline(2, color=REF, lw=1.1, ls=":")
        for i, matrix in enumerate(order):
            value = layers[layers.matrix.eq(matrix)].sort_values("seed").alpha.to_numpy()
            ax.scatter(value, np.full(5, i) + offsets, s=9, color=BLUE, alpha=0.32, edgecolors="none", zorder=2)
            row = summary.iloc[i]
            color = GREEN if matrix in ["transformer.h.3.attn.c_attn.weight", "transformer.h.3.mlp.c_fc.weight"] else BLUE
            ax.errorbar(row.alpha_mean, i, xerr=row.alpha_sample_sd, fmt="o", color=color,
                elinewidth=1.05, capsize=1.6, markersize=3.2, markeredgecolor="white", markeredgewidth=0.35, zorder=3)
        ax.set(yticks=positions, ylim=(17.55, -0.55), xlabel=r"Fitted exponent $\alpha$")
        grid(ax, axis="x")
        ax.tick_params(axis="y", length=0)
    axes[0].set_yticklabels(labels, fontsize=7.9)
    axes[0].set(xlim=(0.8, 14.7), xticks=[1, 2, 4, 6, 8, 10, 12, 14])
    axes[1].set(xlim=(0.8, 4.8), xticks=[1, 2, 3, 4])
    axes[0].set_title("(a) All 18 unique matrices: full range", loc="left", fontsize=9.2, color=INK, weight="bold")
    axes[1].set_title("(b) Detail near the marginal regime", loc="left", fontsize=9.2, color=INK, weight="bold")
    legend = [
        Line2D([], [], marker="o", ms=4, lw=1, color=BLUE, label="Mean ± SD"),
        Line2D([], [], marker="o", ms=3, lw=0, color=BLUE, alpha=.32, label="Individual seed"),
        Line2D([], [], color=REF, lw=1.1, ls=":", label=r"$\alpha=2$"),
    ]
    axes[0].legend(handles=legend, loc="lower right", frameon=False, fontsize=7.1, handlelength=1.4)
    save(fig, "shakespeare_layer_endpoints")


if __name__ == "__main__":
    endpoints, history, layers = verify_raw()
    corpus = (DATA / "raw/input.txt").read_text()
    assert len(corpus) == 1115394 and len(set(corpus)) == 65
    train_end, validation_end = int(0.9 * len(corpus)), int(0.95 * len(corpus))
    train_targets, test_targets = corpus[1:train_end], corpus[validation_end + 1:]
    counts = Counter(train_targets)
    unigram_ce = -sum(math.log(counts[c] / len(train_targets)) for c in test_targets) / len(test_targets)
    reference = json.loads((DATA / "independent_audit.json").read_text())["unigram_baseline"]["splits"]["test"]
    assert np.isclose(unigram_ce, reference["ce_nats_per_character"], atol=1e-10)
    learning_figure(endpoints, history)
    layer_figure(layers)
    print(f"Verified five seeds, {len(history)} loss records, {len(layers)} endpoint fits.")
    print(f"Weighted alpha: {endpoints.weighted_alpha.mean():.9f} ± {endpoints.weighted_alpha.std(ddof=1):.9f}")
    print(f"Test CE: {endpoints.test_loss.mean():.9f} ± {endpoints.test_loss.std(ddof=1):.9f}")
    print(f"Train-only unigram test CE: {unigram_ce:.9f}; perplexity {math.exp(unigram_ce):.9f}")
