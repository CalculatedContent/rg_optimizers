"""Reproduce the five frozen SGDM runs using the original bundled worker.

No Git checkout or dataset download is required. ``--check-only`` uses only
Python's standard library and does not import PyTorch, create outputs, or train.
The worker's numerical code, checkpoints, and resume protocol are unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys

SOURCE_COMMIT = "39f2fb75a3c023d8d90abe11ab06308d1bf3919e"
DESIGN_SHA256 = "866c32768c3c1c1204694054b9736507f34cf6f23fa7ccf341807a1307cb6d31"
RECIPES_SHA256 = "255c9edb6e54c908035e6eb5d18cbe571785df128f125521b0a4db712e26f734"
CORPUS_SHA256 = "86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed"
SEEDS = tuple(range(1340, 1345))
TARGET = 20_000
BUNDLE = Path(__file__).resolve().parent
EXPECTED_RECIPE = {
    "id": "sgdm_lr0.1_m0.9", "optimizer": "SGDM", "peak_lr": 0.1,
    "weight_decay": 0.0, "momentum": 0.9, "nesterov": False, "dampening": 0.0,
}


def read_json(path):
    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def inside(root, relative):
    relative = Path(relative)
    require(not relative.is_absolute() and ".." not in relative.parts,
            f"Invalid relative manifest path: {relative}")
    path = (root / relative).resolve()
    require(path.is_relative_to(root.resolve()), f"Manifest path escapes its root: {relative}")
    return path


def completed_result_matches(path, job, design_sha256):
    """Check identity and completeness; do not require bit-identical new metrics."""
    if not Path(path).is_file():
        return False
    try:
        result = read_json(path)
        endpoint = result["endpoint"]
        if not (result.get("completed") is True and result["job"] == job
                and endpoint["step"] == TARGET
                and result["design_sha256"] == design_sha256):
            return False
        expected_counts = {"train": 1_003_853, "validation": 55_769, "test": 55_769}
        for split, count in expected_counts.items():
            metrics = endpoint["metrics"][split]
            if not (metrics["evaluated_targets"] == count
                    and math.isfinite(metrics["loss_nats_per_character"])
                    and metrics["loss_nats_per_character"] >= 0
                    and math.isfinite(metrics["perplexity"])
                    and metrics["perplexity"] >= 1
                    and 0 <= metrics["next_character_accuracy"] <= 1):
                return False
        alpha = endpoint["alpha"]
        matrices = alpha["matrices"]
        if not (alpha["unique_matrices"] == alpha["successful_fits"] == 18
                and len(matrices) == 18
                and len({matrix["matrix"] for matrix in matrices}) == 18):
            return False
        for matrix in matrices:
            if len(matrix["fits"]) != 1:
                return False
            fit = matrix["fits"][0]
            if not (fit.get("status") == "success" and math.isfinite(fit["alpha"])
                    and math.isfinite(fit["D"]) and fit["D"] >= 0
                    and fit["num_pl_spikes"] > 0):
                return False
        return True
    except (OSError, ValueError, KeyError, TypeError, OverflowError):
        return False


def validate_bundle():
    """Check every frozen source, the corpus, archival records, and all five jobs."""
    protocol = BUNDLE / "data" / "protocol"
    design_path, recipes_path = protocol / "design.json", protocol / "recipes.json"
    require(sha256(design_path) == DESIGN_SHA256, "Frozen design.json checksum differs")
    require(sha256(recipes_path) == RECIPES_SHA256, "Frozen recipes.json checksum differs")
    design, recipes = read_json(design_path), read_json(recipes_path)
    require(recipes["design_sha256"] == DESIGN_SHA256, "Recipes refer to a different design")
    require(design["input_sha256"] == CORPUS_SHA256, "Design has a different corpus")
    require(design["max_steps"] == TARGET, "Unexpected training budget")
    require(design["confirmation_seeds"] == recipes["confirmation_seeds"] == list(SEEDS),
            "Frozen confirmation seeds differ")
    require(recipes["selected"]["SGDM"] == EXPECTED_RECIPE, "Frozen SGDM recipe differs")
    require(EXPECTED_RECIPE in design["candidates"], "SGDM recipe is absent from the design")

    source = BUNDLE / "reproduction" / "source"
    manifest = read_json(BUNDLE / "reproduction" / "source_manifest.json")
    require(manifest["source_commit"] == SOURCE_COMMIT, "Source provenance differs")
    declared = manifest["files"]
    require(isinstance(declared, dict) and declared, "Empty source manifest")
    for relative, expected in declared.items():
        path = inside(source, relative)
        require(path.is_file(), f"Missing bundled source: {relative}")
        require(sha256(path) == expected, f"Bundled source checksum differs: {relative}")
    actual = {p.relative_to(source).as_posix() for p in source.rglob("*")
              if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"}
    require(actual == set(declared),
            "Source file inventory differs: "
            f"missing={sorted(set(declared) - actual)}, extra={sorted(actual - set(declared))}")
    original_hashes = {
        "comparison": {p.name: sha256(p) for p in sorted(
            (source / "short_test_optimizer_comparison").glob("*.py"))},
        "baseline": {p.relative_to(source / "short_test").as_posix(): sha256(p)
                     for p in sorted((source / "short_test").rglob("*.py"))},
    }
    require(original_hashes == design["source_sha256"],
            "Source hashes do not match the original worker's frozen contract")

    corpus = BUNDLE / "data" / "raw" / "input.txt"
    require(sha256(corpus) == CORPUS_SHA256, "TinyShakespeare corpus checksum differs")
    text = corpus.read_text(encoding="utf-8")
    require(len(text) == 1_115_394 and len(set(text)) == 65, "Corpus dimensions differ")
    raw_hashes = read_json(BUNDLE / "data" / "raw_sha256.json")
    for relative, expected in raw_hashes.items():
        require(sha256(inside(BUNDLE, relative)) == expected,
                f"Original measurement checksum differs: {relative}")
    jobs = {}
    for seed in SEEDS:
        record_path = BUNDLE / "data" / "raw" / f"seed{seed}_result.json"
        expected_job = {"phase": "confirmation", "recipe": EXPECTED_RECIPE, "seed": seed}
        require(completed_result_matches(record_path, expected_job, DESIGN_SHA256),
                f"Frozen SGDM result/job is incomplete or mismatched for seed {seed}")
        jobs[seed] = read_json(record_path)["job"]
    return design, jobs, source, corpus, len(declared)


def validate_environment(design):
    """Read installed package metadata without importing the numerical libraries."""
    require(os.name == "posix", "The original worker requires Unix fcntl; use Linux or WSL")
    problems = []
    for package, expected in design["versions"].items():
        try:
            installed = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            problems.append(f"{package}: missing (requires {expected})")
            continue
        # A CPU-specific build can append +cpu without changing the release.
        if installed.split("+", 1)[0] != expected.split("+", 1)[0]:
            problems.append(f"{package}: installed {installed}, requires {expected}")
    require(not problems, "Training environment differs:\n  " + "\n  ".join(problems)
            + "\nInstall reproduction/source/short_test/requirements.txt in Python 3.12.")


def copy_frozen(source, target):
    if target.exists():
        require(target.is_file() and target.read_bytes() == source.read_bytes(),
                f"Existing protocol differs; choose a new output directory: {target}")
    else:
        atomic_write(target, source.read_bytes())


def atomic_write(target, content):
    temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")
    try:
        temporary.write_bytes(content)
        temporary.replace(target)
    finally:
        if temporary.exists():
            temporary.unlink()


def run_worker(command, cwd):
    """Forward interruption so the original worker can save its checkpoint."""
    child = subprocess.Popen(command, cwd=cwd)
    old_handlers = {}

    def request_stop(signum, _frame):
        if child.poll() is None:
            child.send_signal(signum)

    try:
        for sig in (signal.SIGINT, signal.SIGTERM):
            old_handlers[sig] = signal.signal(sig, request_stop)
        return child.wait()
    finally:
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=BUNDLE / "runs" / "sgdm",
                        help="New or matching output directory (default: bundle/runs/sgdm)")
    parser.add_argument("--seeds", nargs="+", type=int, choices=SEEDS, default=list(SEEDS),
                        help="Frozen seeds to run, in order (default: all five)")
    parser.add_argument("--check-only", action="store_true",
                        help="Verify bundled source, corpus and all frozen jobs; do not train")
    args = parser.parse_args(argv)
    if len(set(args.seeds)) != len(args.seeds):
        parser.error("Each seed may be specified only once")
    try:
        design, jobs, source, corpus, source_count = validate_bundle()
        print(f"Verified: {source_count} source files; corpus SHA256; frozen protocol; "
              f"all {len(jobs)} SGDM jobs.", flush=True)
        print("Selected seeds: " + ", ".join(map(str, args.seeds)), flush=True)
        if args.check_only:
            print("Check complete. No numerical libraries imported; no training or output writes.")
            return 0
        validate_environment(design)
        work = args.output.expanduser().resolve()
        require(work != BUNDLE and not any(work.is_relative_to(BUNDLE / part)
                                          for part in ("data", "reproduction")),
                "Choose an output directory outside the bundled data and reproduction sources")
        work.mkdir(parents=True, exist_ok=True)
        import fcntl
        with (work / "launcher.lock").open("a") as batch_lock:
            try:
                fcntl.flock(batch_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError(f"Another launcher is using {work}") from None
            for name in ("design.json", "recipes.json"):
                copy_frozen(BUNDLE / "data" / "protocol" / name, work / name)
            if (work / "PAUSE").exists():
                print(f"Paused by {work / 'PAUSE'}. Remove that file to resume.")
                return 75
            worker = source / "short_test_optimizer_comparison" / "comparison.py"
            for seed in args.seeds:
                job = jobs[seed]
                folder = work / "confirmation" / f"{job['recipe']['id']}_seed{seed}"
                folder.mkdir(parents=True, exist_ok=True)
                job_file = folder / "job.json"
                if job_file.exists():
                    require(read_json(job_file) == job, f"Existing job differs: {job_file}")
                else:
                    atomic_write(job_file, (json.dumps(job, indent=2) + "\n").encode("utf-8"))
                result_file = folder / "result.json"
                if result_file.exists():
                    require(completed_result_matches(result_file, job, DESIGN_SHA256),
                            f"Existing result is incomplete or mismatched: {result_file}")
                    print(f"Seed {seed}: matching completed run retained", flush=True)
                    continue
                require(not (folder / "numerical_failure.json").exists(),
                        f"Seed {seed} has a recorded numerical failure; inspect {folder}")
                code = run_worker([
                    sys.executable, "-u", str(worker), "worker", "--output", str(work),
                    "--data", str(corpus), "--job", str(job_file), "--target", str(TARGET),
                ], source)
                if code == 75:
                    print(f"Seed {seed}: checkpoint saved; rerun the same command to resume.")
                    return 75
                require(code == 0, f"Seed {seed}: original worker exited with code {code}; inspect {folder}")
                require(completed_result_matches(result_file, job, DESIGN_SHA256),
                        f"Seed {seed}: worker did not produce a complete matching result; inspect {folder}")
        print(f"Completed/retained {len(args.seeds)} SGDM runs: {work / 'confirmation'}")
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
