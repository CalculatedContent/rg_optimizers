# Reproduce Shakespeare GPT with SGD and momentum

The package contains the original training implementation, the exact corpus,
the frozen protocol, and all five SGDM job records. A repository checkout or
notebook is not needed. The launcher invokes only the five SGDM confirmation
jobs and uses `reproduction/source/` directly; it does not download code or data.

## 1. Check the package before installing anything

From the extracted package directory:

```bash
python run_sgdm_only.py --check-only
```

This uses only Python's standard library. It verifies the corpus checksum,
all 15 bundled source files, the original worker's 13 Python-source hashes,
the frozen design and SGDM recipe, and all five original result/job records.
It imports no numerical libraries, creates no output directory, and starts no
training. The check covers every frozen job even when `--seeds` selects a subset.

## 2. Prepare the recorded environment

Use Python 3.12 on Linux; Windows users can use WSL. The original worker uses
Unix file locks. A CPU build of PyTorch is sufficient. Install the pinned
packages in a clean environment:

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r reproduction/source/short_test/requirements.txt
```

The requirements record PyTorch 2.14.1, NumPy 2.3.5, SciPy 1.17.0,
WeightWatcher 0.7.7, powerlaw 2.0.0, Matplotlib 3.10.8, and pandas 2.2.3.
Package installation needs access to a package index unless these packages
are already available locally. Training and figure regeneration use the
bundled files. The launcher checks the five numerical package versions in
the original design before starting a worker.

## 3. Run the five seeds

```bash
python run_sgdm_only.py --output runs/sgdm
```

The default output directory is `runs/sgdm` beside the launcher, so the following
also runs all five seeds:

```bash
python run_sgdm_only.py
```

Seeds 1340–1344 run sequentially for 20,000 updates each, using one CPU thread.
The original runs took approximately 30 minutes per seed; local runtime
depends on the CPU and software environment. To start with one seed:

```bash
python run_sgdm_only.py --seeds 1340 --output runs/sgdm
```

Rerun the all-seed command later to retain that completed seed and run the
remaining four. Only seeds from the frozen five-seed protocol are accepted.

The source implementation is preserved byte for byte at commit
`39f2fb75a3c023d8d90abe11ab06308d1bf3919e`. The launcher reads the selected
SGDM recipe from the frozen protocol; it does not rerun calibration or change
hyperparameters. The appendix describes the separate validation-based
calibration procedure. Historical supporting source files are included because
the original worker verifies their hashes, but the launcher does not execute
their training entry points.

## 4. Resume and inspect results

The original worker checkpoints every 250 updates and evaluates loss every
500 updates. Interrupting a running job forwards the signal to the worker
so it can save its state. Exit code 75 means the worker paused. Rerun the same
command and output path to resume the saved model, optimizer, random-number
states, and monitoring history.

For an explicit pause, create a file named `PAUSE` in the output directory.
Remove that file before resuming. Matching completed runs are retained;
conflicting protocol files, jobs, incomplete results, or recorded numerical
failures are reported rather than overwritten. The launcher never loads a
checkpoint itself; the unchanged worker performs its original resume checks.

Each run writes to:

```text
runs/sgdm/confirmation/sgdm_lr0.1_m0.9_seed1340/
```

Replace `1340` with the desired seed. Useful files are:

| File | Contents |
|---|---|
| `job.json` | Frozen recipe, seed, and confirmation phase |
| `last.pt` | Latest model, optimizer, random states, and monitoring history |
| `progress.json` | Current saved step and most recent evaluation |
| `summary_20000.json` | Forty training/validation observations and timing |
| `selection.json` | Endpoint and minimum-validation checkpoint selection |
| `result.json` | Full-partition loss, perplexity, accuracy, and per-matrix fits |

The endpoint used in the paper is always `result.json["endpoint"]` at update
20,000. The minimum-validation checkpoint is retained separately. Compare
new local results with the published measurements in `data/raw/`; keep these
two sets distinct. Hardware and numerical-library builds can affect exact
floating-point results even with identical seeds and source.

## 5. Regenerate the published figures

```bash
python make_figures.py
```

This regenerates the manuscript figures from the bundled **original**
measurements, with their saved hashes and table checks. It does not read
`runs/sgdm`, does not launch training, and does not present locally rerun
models as the published runs. The notebook also displays a separate table
computed from the new or retained local `result.json` files.

## Optional notebook

Open `Reproduce_Shakespeare_SGDM.ipynb` in a Python 3.12 notebook environment.
It performs the same integrity check, provides an optional dependency-install
cell, launches the five SGDM jobs, displays their local endpoint measurements,
and then explicitly regenerates the published figures from the archived data.
All notebook outputs are empty in the delivered file: no new training was
performed while preparing this package.

The corpus, original sources, protocol files and measurement records are
inputs. Keep edits and experimental variants in a separate copy and output
directory so the frozen reproduction remains inspectable.
