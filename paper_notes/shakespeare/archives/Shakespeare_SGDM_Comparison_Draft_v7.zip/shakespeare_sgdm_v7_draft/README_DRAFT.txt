SHAKESPEARE GPT — COMPARISON REVISION, SOURCE DRAFT

This bundle revises the subsection and reproduction appendix in LaTeX.
It includes the 2,000-versus-20,000-update comparison, the confidence-weighted
tail-adjusted endpoint alpha, and a separate review of the existing graft
experiments. No training was run and no manuscript PDF was generated or
updated. The new float placement and final page count have not been rendered.

Paper files
-----------
section_shakespeare_sgdm.tex
    Replacement subsection, with a full-width comparison table. Insert after
    the optimizer experiments. It refers to the preceding averaging equation.
appendix_shakespeare_reproduction.tex
    Complete reproduction appendix, now including the individual five-seed
    endpoint table moved out of the main subsection.
Shakespeare_SGDM_Complete_Draft.tex
Shakespeare_SGDM_Subsection_Draft.tex
Shakespeare_SGDM_Appendix_Draft.tex
    Existing two-column preview wrappers, retained as source only.
figures/
    Unchanged vector and PNG figures from v6. No new spectral trajectory is
    inferred. The alpha panel compares final models across seeds.
references_shakespeare_bibitems.tex
references_shakespeare.bib
    Entries for the parent's bibliography. The subsection has no local
    bibliography or acknowledgments.

Integration
-----------
Copy the drop-in TeX files and figures into the parent manuscript. Use:
  \input{section_shakespeare_sgdm.tex}
after the optimizer experiments, and:
  \input{appendix_shakespeare_reproduction.tex}
after the optimizer reproduction appendix in the existing appendix region.
The parent supplies its existing marginalbox tcolorbox style and the labels
and bibliography entries described in the TeX comments. Do not introduce
another \appendix command inside the parent.

Review and data
---------------
REVIEW_NOTES.txt explains the comparison, missing early SGDM spectra, the
completed graft learning-rate calibration, and the proposed follow-up.
data/sgdm_2000_20000_audit.json contains per-seed short/long measurements.
data/graft_and_matched_controls_audit.json contains full-precision original
AdamW and SGDM endpoints and the two single-seed graft endpoints.
review/graft/ contains the checked-in graft implementation, calibration,
comparison records and raw result JSONs used for this review.

All spreads in the subsection are sample standard deviations across seeds.
Alpha at 2,000 SGDM updates is explicitly unavailable. Validation and test
perplexities are separate metrics. The matched AdamW result is retained as
performance context, and no optimizer-superiority claim is made for SGDM.
The graft results and follow-up proposals remain outside the main subsection.

Reproduction
------------
The unchanged v6 frozen SGDM worker, corpus, source manifest, launcher,
requirements, and optional notebook are retained. TRAINING_REPRODUCTION.md
and the appendix give the complete procedure independently of a repository
or notebook. run_sgdm_only.py uses that bundled source. No change to numerical
training code was made for this draft.

The corpus and existing measurements are under data/raw/; the original
model/optimizer protocol is under data/protocol/. The original source and
manifest are under reproduction/. SHA256SUMS.txt covers this draft bundle.
The two figure PDF files are existing assets, not newly compiled manuscript
PDFs. Version 6 document PDFs remain unchanged outside this source bundle.
