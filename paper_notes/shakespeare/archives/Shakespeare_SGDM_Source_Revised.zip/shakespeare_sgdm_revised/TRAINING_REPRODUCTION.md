# Rerun the five SGDM seeds on CPU

The main README explains how to rebuild the paper and figures from the saved
measurements. To repeat training itself, use the original study's documented
Linux/Python 3.12 environment, on your own CPU or in a suitable Linux VM.

The commands below use the original frozen runner and the exact five saved
SGDM jobs. They have been checked against that runner's interface; training
was not repeated while preparing the manuscript.

```bash
git clone https://github.com/CalculatedContent/rg_optimizers.git rg_optimizers_sgdm
cd rg_optimizers_sgdm
git checkout 39f2fb75a3c023d8d90abe11ab06308d1bf3919e

python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r short_test/requirements.txt
```

Run the supplied launcher with absolute paths to the extracted subsection
bundle, frozen repository checkout, and a new output directory:

```bash
python /absolute/path/to/shakespeare_sgdm_revised/run_sgdm_only.py \
  --repo /absolute/path/to/rg_optimizers_sgdm \
  --output /absolute/path/to/sgdm_shakespeare_runs
```

The launcher uses the original `worker` command sequentially for seeds
1340–1344, with 20,000 updates per seed and one CPU thread. It checks the source
commit and design hash, preserves matching completed runs, and lets the original
worker resume existing checkpoints. It checks each final result before reporting
completion, including workers that exit after recording a numerical failure.
The worker also checks frozen source hashes. The launcher
runs only the saved SGDM jobs; it does not repeat optimizer calibration.

The recorded total time was about 30 minutes per seed, including monitoring
and final evaluation. Runtime on another CPU will differ. The original
environment and exact numerical recipe are retained in `data/protocol/` and
the saved result files. Source requirements and dependency availability govern
whether that environment can be recreated on a given machine.

Results are written under the chosen output directory's `confirmation/`
subdirectory. Each seed produces its own result, history, and checkpoint files.

The original experiment's ordinary `comparison.py run` command reproduces the
broader optimizer comparison. Use the supplied launcher for this SGDM-only
paper example.
