SHAKESPEARE GPT — TWO-PAGE SECTION, VERSION 8

The PDF is a new two-page, two-column subsection with the parent paper's
blue results-box style. It contains the 2,000-update reference/graft
comparison, the five-seed long-run SGDM result, and two new publication
figures. No numerical training was performed for this revision.

PAPER FILES

Shakespeare_GPT_Section_v8.pdf
    The visually checked, two-page preview.
Shakespeare_GPT_Section_v8.tex
    Standalone LaTeX wrapper. Compile twice with pdflatex in this folder.
section_shakespeare_gpt.tex
    Drop-in subsection after the optimizer experiments.
appendix_shakespeare_reproduction.tex
    Self-contained original SGDM procedure, five-seed endpoint table,
    graft update/calibration procedure, and checkpoint/uncertainty details.
    This appendix is separate from the two-page main preview.
figures/
    Two publication figures as vector PDF and PNG.
references_shakespeare_bibitems.tex and references_shakespeare.bib
    Entries for the existing parent bibliography. No local References or
    Acknowledgments section is added to the subsection.

INSERTION INTO THE PARENT PAPER

Copy section_shakespeare_gpt.tex and figures/ into the manuscript and use
  \input{section_shakespeare_gpt.tex}
after the optimizer-experiment subsection. Insert the reproduction appendix
after the existing optimizer appendix. The parent supplies its existing
marginalbox tcolorbox style and bibliography. Merge the KarpathyCharRNN and
KarpathyNanoGPT entries into that bibliography; MartinPengMahoney2021 is
already used by the parent. The averaging equation is referenced textually
as the equation in the preceding subsection, with no invented equation number.

The standalone wrapper uses 10-point two-column letter paper, 0.68-inch
margins, and 0.23-inch column separation. It replaces parent citation and
appendix macros with readable source links and Appendix A for the preview.
Float placement and numbering naturally inherit the parent manuscript.
The local font-map fallback is inert on a normal TeX Live installation.

WHAT THE FIGURES AND ERROR BARS MEAN

Figure 1a shows full-validation perplexity. Native AdamW and SGDM have five
seeds and mean +/- sample-SD ribbons. Each graft curve is one seed.
Figure 1b shows the actual recorded graft alpha histories and the SGDM
20,000-update endpoint only. SGDM dots are its five independent model
averages; the bar is the 95% Student-t interval for their mean.
Figure 2 shows all 90 SGDM layer fits. Layer bars are mean +/- sample SD
across the five seeds. Layer heterogeneity, seed variability, and fit-quality
weights are separate quantities.

Every spectral average uses the requested confidence-weighted, tail-adjusted
estimator on all 18 unique matrices: weights sqrt(num_pl_spikes)/(D+0.02),
ordinary fitted alpha, tied embedding counted once. It is not WeightWatcher's
separate alpha_weighted field. The subsection refers to the previously
derived equation instead of redefining it.

The tuned graft at 2,000 updates has CE1.851648, PPL6.370309, and alpha1.808663.
The original reference-0.1 graft instead has CE1.933336, PPL6.912535, and
alpha2.172067. They are kept distinct throughout. Original AdamW and SGDM
have no saved 2,000-update spectra; those table entries remain unavailable.
The original native AdamW control predicts better at20,000 updates. The
observed tuned-graft advantage is early and measured on one confirmation seed.

DATA AND REPRODUCTION

python make_figures.py
    Checks the 22 input hashes, recomputes the table data and weighted alpha,
    and rebuilds both figures without training or network access.
FIGURE_REPRODUCTION.md
    Plot definitions, raw-data provenance, and uncertainty conventions.
data/exact_metrics_and_uncertainty.json
    Independent audit with original seed metrics, both graft settings,
    paired differences, Student-t intervals, and the contextual reference.
data/raw_manifest.json and data/raw/
    The 22 exact JSON plotting inputs, plus the earlier SGDM corpus and
    reproduction records retained from the original bundle.

TRAINING_REPRODUCTION.md, requirements.txt, run_sgdm_only.py,
Reproduce_Shakespeare_SGDM.ipynb, and reproduction/source/
    Unchanged frozen SGDM training code and complete bundled corpus. Follow
    these instructions or the appendix to reproduce SGDM from scratch.
reproduction/graft_source/
    Archived graft code and its portable model/runtime dependencies, with
    a source-hash manifest and the actual tuned run's environment/design.
    Use the root requirements.txt for the recorded numerical package versions;
    the upstream portable requirements file is retained as source history.
    The appendix gives commands for original-graft reproduction and the
    completed reference-rate calibration. These commands start fresh training.

The current revision recomputed measurements and rendered documents; it did
not execute fresh training or promise bitwise reproduction across platforms.
SHA256SUMS.txt records the packaged files. The ZIP excludes LaTeX auxiliary
logs and temporary render images.
