# Shakespeare GPT: subsection and reproducibility appendix

Version 6 contains a two-page, two-column subsection and a three-page
reproducibility appendix. All numerical results are the original five SGDM
runs. This revision changes the presentation and makes reproduction independent
of an external repository or notebook. No model was retrained for this revision.

## Paper files

| File | Purpose |
|---|---|
| `Shakespeare_SGDM_Complete_v6.pdf` | Five-page preview: subsection followed by appendix |
| `Shakespeare_SGDM_Subsection_v6.pdf` | Two-page subsection alone |
| `Shakespeare_SGDM_Appendix_v6.pdf` | Three-page appendix alone |
| `section_shakespeare_sgdm.tex` | Drop-in subsection, without a preamble |
| `appendix_shakespeare_reproduction.tex` | Drop-in appendix, without a preamble |
| `Shakespeare_SGDM_Complete_v6.tex` | Standalone wrapper for both parts |
| `Shakespeare_SGDM_Subsection_v6.tex`, `Shakespeare_SGDM_Appendix_v6.tex` | Separate preview wrappers |
| `references_shakespeare_bibitems.tex` | Entries for the parent's existing `thebibliography` |
| `references_shakespeare.bib` | Equivalent entries for a BibTeX workflow |
| `figures/` | Both figures as vector PDF and PNG |

The blue box summarizes results in three single-line equation bullets. The
main text refers to the preceding confidence-weighted, tail-adjusted averaging
equation. It introduces a familiar small CPU model that readers can repeat.
The appendix gives the architecture, initialization order, exact learning-rate
indexing, sampling, monitoring, evaluation, spectral fits, and aggregation.

### Insert into the parent paper

Copy the two drop-in TeX files and `figures/` into the manuscript directory.
After the optimizer-experiment subsection, add:

```latex
\input{section_shakespeare_sgdm.tex}
```

After the optimizer-reproduction appendix, in the parent's appendix region, add:

```latex
\input{appendix_shakespeare_reproduction.tex}
```

Do not add a second `\appendix` command to the parent document. Its numbering
supplies the correct letter for `app:shakespeare-reproduction`; the previews
show Appendix A. The main subsection uses the parent's existing theoretical
label `sxn:model_average_marginality` and bibliography key `MartinPengMahoney2021`.
The inspected parent uses an inline `thebibliography`: insert
`references_shakespeare_bibitems.tex` inside that existing environment.
For a BibTeX version, merge the equivalent entries from the `.bib` file.
The new keys are `KarpathyCharRNN` and `KarpathyNanoGPT`.
The corpus citation points to the char-rnn release;
no dedicated original TinyShakespeare paper is assumed.

The averaging-equation reference is textual to avoid inventing an equation
number. Drop-in citation macros use ordinary `\cite`. Preview wrappers use
linked source/author citations and create no separate References or
Acknowledgments section.

The parent needs `amsmath`, `amssymb`, `graphicx`, `booktabs`, `caption`,
`hyperref`, `ragged2e`, `tcolorbox`, and its existing `marginalbox` style.
Wrappers use 10-point, two-column letter paper, 0.68-inch margins, 0.23-inch
column separation, and the paper's blue box style. Numbering and float positions
inherit the full manuscript when inserted.

Compile in a normal TeX Live installation:

```bash
pdflatex -interaction=nonstopmode -halt-on-error Shakespeare_SGDM_Complete_v6.tex
pdflatex -interaction=nonstopmode -halt-on-error Shakespeare_SGDM_Complete_v6.tex
```

## Reproduce training without a checkout

The package includes the exact corpus and all source needed by the frozen
worker. The appendix specifies the scientific procedure independently of the
notebook. `TRAINING_REPRODUCTION.md` gives the command-line workflow.

```bash
python run_sgdm_only.py --check-only
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_sgdm_only.py --output runs
```

The integrity check needs only the Python standard library. The training
command runs seeds 1340–1344 sequentially for 20,000 updates each. To try a
single seed, add `--seeds 1340`. The original worker preserves/resumes its
complete last checkpoint. No dataset download, Git checkout, or notebook is
required after extraction and dependency installation. Recorded CPU runtime
was about 30 minutes per seed; another machine may differ.

`Reproduce_Shakespeare_SGDM.ipynb` is an optional interface to the same workflow.
It distinguishes new local runs from archived measurements. The launcher does
not repeat hyperparameter calibration; the appendix gives the six-candidate
calibration and continuation procedure for independent implementation.

### Frozen source and validation

`reproduction/source/` preserves all 13 Python files in the frozen design,
plus the requirements and nanoGPT MIT license. Every Python file matches its
SHA256 in `data/protocol/design.json`. All 15 source files are listed in
`reproduction/source_manifest.json`. The numerical worker is unchanged from
revision `39f2fb75a3c023d8d90abe11ab06308d1bf3919e` of `rg_optimizers`.
Its original broader controller contains other optimizer code; the launcher
invokes only SGDM confirmation workers. Auxiliary source files are retained
because the worker validates the entire original source inventory.

The new launcher passed its integrity checks under Python with site-packages
disabled. Altered source and mismatched results were rejected. Its syntax and
notebook cells were checked. The PDFs were compiled and visually inspected.
No full training was executed during this revision. Exact seeds and package
versions do not imply bitwise portability across machines or library builds.

## Rebuild the published plots

```bash
python make_figures.py
```

This reads only original measurements in `data/raw/`, checks their hashes,
recomputes the weighted averages and unigram baseline, verifies the saved
endpoint table, and writes both figures. It does not train or consume fresh
run outputs. New results are written under the directory chosen with `--output`.

The loss figure shows five individual training/validation trajectories and
their means. Its weighted-alpha panel compares endpoints across seeds. No alpha
time series was recorded: only endpoint and minimum-validation spectra exist.
All paper figures and final statistics use step 20,000. Only seed 1344 also has
a distinct selected checkpoint at step 19,000.

## Numerical checks

All spreads are sample SD across the five seeds.

| Quantity | Mean ± sample SD |
|---|---:|
| Confidence-weighted, tail-adjusted alpha | 2.218823 ± 0.072530 |
| Unweighted alpha | 2.950698 ± 0.211426 |
| Full training cross-entropy | 1.363934 ± 0.010215 nats/character |
| Full validation cross-entropy | 1.528045 ± 0.008810 nats/character |
| Full test cross-entropy | 1.694025 ± 0.008160 nats/character |
| Test perplexity | 5.441484 ± 0.044370 |
| Test accuracy | 51.284764% ± 0.122313 percentage points |
| Training, monitoring and final evaluation | 29.744827 ± 2.002260 minutes/seed |

Within each seed, the estimator uses
`w = sqrt(num_pl_spikes) / (D + 0.02)` and
`alpha_cw = sum(w * alpha) / sum(w)`. All 18 unique matrices enter; tied
token/output weights are counted once. Use the raw `alpha` field, not
WeightWatcher's distinct `alpha_weighted`; add no matrix-size multiplier.
The five resulting model averages are averaged equally.

The training-frequency unigram predictor has test loss 3.361967 and perplexity
28.845885 on the same targets. NanoGPT's example losses provide context under
different splits, training budgets, and evaluation methods. They do not
establish literature-leading accuracy. The finding is a model average near two,
useful language prediction, and substantial variation among individual matrices.

## Provenance

- Corpus SHA256: `86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed`.
- Numerical source revision: `39f2fb75a3c023d8d90abe11ab06308d1bf3919e`.
- Paper style: `rg_theory_paper_arxiv`, revision `2d5e752c65188bf8a194163a01b76839b516252d`.
- Plot style: `rg_optimizers` PR 182, head `3c311af2a36cc11c324c3dd11a2c1931435c3178`.
- Original archives: `GPT_AdamW_SGDM_20261023T031957_Part006.zip` (seed 1340)
  and `Part007.zip` (seeds 1341–1344).
- Corpus: https://github.com/karpathy/char-rnn
- Model and reference losses: https://github.com/karpathy/nanoGPT
- Reference split/evaluation: nanoGPT `data/shakespeare_char/prepare.py` and `train.py`.
- Larger-model discussion: https://doi.org/10.1038/s41467-021-24025-8

Prepared November 24, 2026. The parent manuscript and earlier delivered versions
were preserved.
