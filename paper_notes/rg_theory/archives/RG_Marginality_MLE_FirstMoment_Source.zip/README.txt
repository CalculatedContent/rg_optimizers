RG Marginality / MLE / First-Moment Insert

Files
-----
RG_Marginality_MLE_FirstMoment_TwoPage_Insert.tex
  Recovered original subsection source, unchanged.

figures/first_moment_log_shells.pdf
  Original vector figure recovered from the Form XObject embedded in
  the supplied PDF. It contains the two plot panels without the page
  watermark or caption. The caption remains editable in the LaTeX.

main.tex
  New standalone wrapper supplying the original subsection's required
  macros, packages, and box style. Sets section 5.5.1, equations 65-75,
  Figure 10, and page numbering beginning at 15. This wrapper is newly
  supplied; the original manuscript preamble was not part of the insert.

main.pdf
  PDF compiled from the supplied standalone wrapper.

Compile
-------
Run from this directory:
  pdflatex main.tex
  pdflatex main.tex

For Overleaf, upload this ZIP and choose main.tex as the main document.

Integration into an existing paper
----------------------------------
Copy the subsection .tex and figures/first_moment_log_shells.pdf into
your paper directory. Ensure the required packages, macros, marginalbox
style, and takeaway command are defined (see main.tex), then use:
  \input{RG_Marginality_MLE_FirstMoment_TwoPage_Insert.tex}

The standalone wrapper preserves the content, notation, equation labels,
and figure. Its visual styling is reconstructed; the original DRAFT
watermark is not included in the standalone wrapper.
