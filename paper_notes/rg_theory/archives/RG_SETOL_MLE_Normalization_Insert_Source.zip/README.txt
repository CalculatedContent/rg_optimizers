SETOL--MLE--Frobenius normalization alignment: October 27, 2026

Two-page insert PDF: RG_SETOL_MLE_Normalization_Two_Page_Insert.pdf
Insert source: RG_SETOL_MLE_Normalization_Insert.tex
Standalone source: rg_normalization_alignment_standalone.tex

The insert is a \subsection, not a \subsubsection. In the full draft it
follows RG Scale counting (Section 5.5) and is numbered Section 5.6.
The following alpha=3 geometry section is promoted to Section 5.7 to
avoid nesting an unrelated result under the normalization section.

To compile the standalone PDF, keep rg_normalization_alignment_standalone.tex,
rg_normalization_alignment_subsection.tex, and figures/ together and run:
  pdflatex rg_normalization_alignment_standalone.tex
  pdflatex rg_normalization_alignment_standalone.tex

Data: SETOL_ERG_reproduction.zip (30 MNIST MLP checkpoints, six learning
rates x five seeds). CSV contains FC1 and FC2 diagnostics, 60 rows.
The third figure uses a finite-Pareto plug-in Monte Carlo conditional on
each observed maximum; the interval omits fitted-parameter uncertainty.
The MLE/Frobenius equality is not claimed to follow from alpha=2 alone.
