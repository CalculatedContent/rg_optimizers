from pathlib import Path
import io,zipfile,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/mnt/data/RG_Normalization_Alignment'); figdir=root/'figures'
z=zipfile.ZipFile('/mnt/data/erg_repro/SETOL_ERG_reproduction.zip')
rows=[]
for lr in [1,2,4,8,16,32]:
 for seed in range(1,6):
  prefix=f'SETOL_ERG_reproduction/results/seed_{seed}_lr_{lr}/'
  npz=np.load(io.BytesIO(z.read(prefix+'spectra.npz')))
  fits=list(csv.DictReader(io.StringIO(z.read(prefix+'weightwatcher_frobenius.csv').decode())))
  mets=list(csv.DictReader(io.StringIO(z.read(prefix+'metrics.csv').decode())))
  for layer in ['FC1','FC2']:
   a=npz[layer];r=next(q for q in fits if q['name']==layer.lower())
   mr=next(q for q in mets if q['name']==layer.lower() and q['normalization']=='frobenius')
   alpha=float(r['alpha']);xmin=float(r['xmin']);mu=float(a.mean());gm=xmin*np.exp(1/(alpha-1));tail=a[a>=xmin]
   assert np.isclose(np.exp(np.log(tail).mean()),gm,rtol=1e-9)
   rows.append(dict(seed=seed,lr_factor=lr,layer=layer,alpha=alpha,KS_D=float(r['D']),xmin=xmin,mu1=mu,s_MLE=gm,delta=np.log(mu/gm),num_PL=int(r['num_pl_spikes']),num_ECS=int(mr['num_ERG_spikes']),gap=int(mr['ERG_gap']),n_tail=len(tail),B=a.max()))
with open(root/'mnist_normalization_60_layer_checkpoints.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.4,'axes.titlesize':9.2,'axes.labelsize':8.1,'xtick.labelsize':7.6,'ytick.labelsize':7.6,'legend.fontsize':7.2,'pdf.fonttype':42})
blue='#17669C';amber='#CB742A';muted='#6B7580';grid='#DDE3E8'
fig,ax=plt.subplots(figsize=(3.42,2.27),layout='constrained')
L=4.0;x=np.linspace(0,L,400);p=np.exp(-x)/(1-np.exp(-L));q=np.full_like(x,1/L)
for j in range(4):ax.axvspan(j,j+1,color=blue,alpha=.027 if j%2 else .065,zorder=0)
ax.plot(x,p,color=amber,lw=2.2,label=r'Counts: $p_2(x)\propto e^{-x}$')
ax.plot(x,q,color=blue,lw=2.3,label=r'First moment: $q_{1,2}(x)=1/L$')
for j in range(5):ax.axvline(j,color=grid,lw=.65,zorder=0)
ax.set(xlim=(0,L),ylim=(0,1.11),xlabel=r'$x=\log(\lambda/a)$  (equal log-width shells)',ylabel='Probability density')
ax.set_xticks([0,1,2,3,4]);ax.legend(frameon=False,loc='upper right',handlelength=2.3)
ax.spines[['top','right']].set_visible(False)
fig.savefig(figdir/'log_shell_mle_first_moment.pdf',bbox_inches='tight',pad_inches=.02)
fig.savefig(figdir/'log_shell_mle_first_moment.png',dpi=230,bbox_inches='tight',pad_inches=.02)
plt.close(fig)
fig,ax=plt.subplots(figsize=(3.42,2.50),layout='constrained')
for layer,c,mark in [('FC1',blue,'o'),('FC2',amber,'s')]:
 sub=[r for r in rows if r['layer']==layer]
 ax.scatter([r['alpha'] for r in sub],[r['delta'] for r in sub],s=18,c=c,marker=mark,alpha=.72,edgecolors='white',linewidths=.35,label=f'{layer}: 30 checkpoints',zorder=3)
 last=[r for r in sub if r['lr_factor']==32]
 ax.scatter([r['alpha'] for r in last],[r['delta'] for r in last],s=34,facecolors='none',edgecolors=c,linewidths=1.05,zorder=4)
ax.axhline(0,color=muted,lw=1,linestyle='--');ax.axvline(2,color=muted,lw=1,linestyle=':')
ax.set(xlabel=r'Pareto MLE exponent $\hat\alpha$',ylabel=r'$\delta=\log(\mu_1/s_{\rm MLE})$',xlim=(1.85,3.95),ylim=(-.88,.20))
ax.grid(axis='y',color=grid,lw=.6);ax.legend(frameon=False,loc='lower right',handletextpad=.3)
ax.text(2.04,.133,r'Proposed matching $(2,0)$',fontsize=7.3,color=muted)
ax.spines[['top','right']].set_visible(False)
fig.savefig(figdir/'mnist_mle_frobenius_mismatch.pdf',bbox_inches='tight',pad_inches=.02)
fig.savefig(figdir/'mnist_mle_frobenius_mismatch.png',dpi=230,bbox_inches='tight',pad_inches=.02)
plt.close(fig)
rng=np.random.default_rng(20261027);obs=[];pred=[];sim=[]
for seed in range(1,6):
 r=next(r for r in rows if r['seed']==seed and r['lr_factor']==32 and r['layer']=='FC1')
 prefix=f'SETOL_ERG_reproduction/results/seed_{seed}_lr_32/'
 arr=np.load(io.BytesIO(z.read(prefix+'spectra.npz')))['FC1']
 tail=arr[arr>=r['xmin']];n=len(tail);B=float(tail.max());a=r['xmin'];alpha=r['alpha']
 edges=np.geomspace(a,B,5)
 actual=np.histogram(tail,bins=edges,weights=tail)[0];obs.append(actual/actual.mean())
 u=rng.random((3000,n-1));power=1-alpha
 samples=(a**power+u*(B**power-a**power))**(1/power)
 gains=np.zeros((len(samples),4))
 for j in range(4):
  in_bin=(samples>=edges[j])&(samples<(edges[j+1] if j<3 else edges[j+1]+1e-9))
  gains[:,j]=(samples*in_bin).sum(axis=1)
 gains[:,-1]+=B
 gains/=gains.mean(axis=1,keepdims=True)
 pred.append(gains.mean(axis=0));sim.append(gains)
obs=np.array(obs);pred=np.array(pred);sim=np.array(sim)
fig,ax=plt.subplots(figsize=(3.42,2.42),layout='constrained')
x=np.arange(1,5);means=obs.mean(axis=0);pmeans=pred.mean(axis=0)
lo,hi=np.quantile(sim.mean(axis=0),[.025,.975],axis=0)
ax.axhline(1,color=muted,lw=1,linestyle=':',label=r'Ideal flat $\alpha=2$')
ax.fill_between(x,lo,hi,color=amber,alpha=.16,label='Pareto plug-in reference, 95%')
ax.plot(x,pmeans,'s--',color=amber,ms=4,lw=1.5,label='Finite-Pareto mean')
ax.errorbar(x,means,yerr=obs.std(axis=0,ddof=1),fmt='o-',color=blue,ms=4,capsize=2.2,lw=1.6,label='Measured FC1 (5 seeds)')
ax.set(xlim=(.8,4.2),ylim=(0,2.25),xticks=x,xlabel='Logarithmic tail shell (low to high)',ylabel='Shell gain / mean gain')
ax.legend(frameon=False,loc='upper left',fontsize=6.7)
ax.grid(axis='y',color=grid,lw=.6);ax.spines[['top','right']].set_visible(False)
fig.savefig(figdir/'mnist_fc1_shells_finite_pareto.pdf',bbox_inches='tight',pad_inches=.02)
fig.savefig(figdir/'mnist_fc1_shells_finite_pareto.png',dpi=230,bbox_inches='tight',pad_inches=.02)
plt.close(fig)
for layer in ['FC1','FC2']:
 for lr in [32]:
  sub=[r for r in rows if r['layer']==layer and r['lr_factor']==lr]
  print(layer,'alpha',np.mean([r['alpha'] for r in sub]),'D',np.mean([r['KS_D'] for r in sub]),'delta',np.mean([r['delta'] for r in sub]),'meanabs gap',np.mean([abs(r['gap']) for r in sub]),'signedgap',np.mean([r['gap'] for r in sub]))
print('OBS BANDS',np.round(obs.mean(axis=0),3),'NULL',np.round(pred.mean(axis=0),3))
