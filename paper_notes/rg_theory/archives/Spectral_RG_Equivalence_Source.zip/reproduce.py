#!/usr/bin/env python3
"""Reproduce the finite-size checks and figure in the spectral RG note.

Dependencies: numpy, scipy, matplotlib. No network access or training data.
Run: OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python reproduce.py
"""
from pathlib import Path
import csv
import json
import math

import numpy as np
from scipy.linalg import eigvalsh
from scipy.special import digamma
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
rows = []
for n in (256, 512, 1024):
    t = 2 * n
    ranks = np.arange(1, t + 1, dtype=float)
    harmonic = np.sum(1.0 / ranks)
    for seed in (42, 43, 44):
        rng = np.random.default_rng(seed)
        y = rng.standard_normal((t, n)) / np.sqrt(ranks[:, None])
        ev = eigvalsh(y.T @ y, check_finite=False)[::-1] / harmonic
        empirical_mean = float(ev.mean())
        ev /= empirical_mean
        cumulative_log = np.cumsum(np.log(ev))
        k = int(np.argmin(np.abs(cumulative_log))) + 1
        rows.append(dict(N=n, T=t, seed=seed, H_T=float(harmonic),
                         empirical_mean_before_correction=empirical_mean,
                         retained_rank=k, cutoff=float(ev[k-1]),
                         trace_log_residual=float(cumulative_log[k-1]),
                         leading_rank=float(math.e*n/harmonic)))

with (ROOT / "finite_size_checks.csv").open("w", newline="") as fh:
    writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

# A finite matrix counterexample with the same critical row-variance weights.
z = np.array([[1., 0., 0.], [1., 1., 0.], [0., 1., 1.]])
y = np.diag(np.arange(1, 4, dtype=float)**(-0.5)) @ z
spectral = eigvalsh(y.T @ y)[-2:][::-1]
coordinate = eigvalsh(y[:2, :2].T @ y[:2, :2])[::-1]

# Check the exact harmonic-sum identity used in the resolvent calculation.
n, t = 100, 200
h = np.sum(1.0 / np.arange(1, t+1))
test_G = 0.1 - 0.3j
u = n * test_G / h
direct = np.sum(1.0/(np.arange(1, t+1)-u)) / h
special = (digamma(t+1-u)-digamma(1-u)) / h
checks = dict(
    spectral_eigenvalue_ratio=float(spectral[0]/spectral[1]),
    coordinate_eigenvalue_ratio=float(coordinate[0]/coordinate[1]),
    digamma_identity_absolute_error=float(abs(direct-special)),
    numpy_version=np.__version__,
    protocol="Gaussian entries; q=N/T=1/2; a=1/2; seeds 42,43,44; empirical full-mean normalization; closest integer trace-log zero",
)
assert checks["digamma_identity_absolute_error"] < 1e-12
assert abs(checks["spectral_eigenvalue_ratio"] - checks["coordinate_eigenvalue_ratio"]) > 1
(ROOT / "algebra_checks.json").write_text(json.dumps(checks, indent=2) + "\n")

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.labelcolor": "#253449", "text.color": "#253449"})
fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.55), layout="constrained")
sizes = np.array([256, 512, 1024])
for ax in axes:
    ax.set_xscale("log", base=2)
    ax.set_xticks(sizes, [str(n) for n in sizes])
    ax.set_xlabel("Covariance dimension N (T = 2N)")
    ax.grid(alpha=.17)
means = [np.mean([r["cutoff"] for r in rows if r["N"]==n]) for n in sizes]
low = [min(r["cutoff"] for r in rows if r["N"]==n) for n in sizes]
high = [max(r["cutoff"] for r in rows if r["N"]==n) for n in sizes]
axes[0].errorbar(sizes, means, yerr=[np.array(means)-low, np.array(high)-means],
                 fmt="o-", color="#17658a", capsize=4, label="Three-seed mean and range")
axes[0].axhline(1/math.e, color="#b0612b", ls="--", label="Asymptotic 1/e")
axes[0].set_ylabel("Selected normalized cutoff")
axes[0].set_ylim(.325,.375)
axes[0].legend(frameon=False, fontsize=7, loc="lower right")
fractions = [np.mean([r["retained_rank"]/n for r in rows if r["N"]==n]) for n in sizes]
predictions = [next(r["leading_rank"]/n for r in rows if r["N"]==n) for n in sizes]
axes[1].plot(sizes, fractions, "o-", color="#17658a", label="Selected fraction, three-seed mean")
axes[1].plot(sizes, predictions, "s--", color="#b0612b", label="Leading asymptotic e / H(T)")
axes[1].set_ylabel("Retained fraction K / N")
axes[1].legend(frameon=False, fontsize=7, loc="lower left")
fig.savefig(ROOT / "finite_size_checks.pdf")
fig.savefig(ROOT / "finite_size_checks.png", dpi=190)
plt.close(fig)
print(json.dumps({"checks":checks,"rows":rows}, indent=2))
