Marginal Spectral Equivalence of Index-Space and ECS Renormalization
Draft research note, 30 October 2026

Main file: Spectral_RG_Equivalence_Note.tex
Compiled document: Spectral_RG_Equivalence_Note.pdf

Scope
-----
The note states a conditional asymptotic equivalence of the marginal retained
spectral descriptions. The integrated-tail assumption (TC) is explicit.
It does not assert that generic coordinate deletion equals SVD truncation,
or that the ensemble supplies a training flow toward alpha = 2.

Reproduce the checks
--------------------
Dependencies: Python 3, numpy, scipy, matplotlib.
Run:
  OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python reproduce.py

This creates finite_size_checks.csv, algebra_checks.json, and the figure
finite_size_checks.pdf / finite_size_checks.png.
Three Gaussian seeds (42, 43, 44) are used for each of N=256,512,1024,
with T=2N and critical row variance t^(-1).

Compile the note
----------------
Use a standard TeX Live installation with amsmath, tcolorbox, lmodern,
microtype, fancyhdr, graphicx, booktabs, and hyperref:
  pdflatex -interaction=nonstopmode -halt-on-error Spectral_RG_Equivalence_Note.tex
  pdflatex -interaction=nonstopmode -halt-on-error Spectral_RG_Equivalence_Note.tex

All calculations use generated matrices. No private training data is included.
